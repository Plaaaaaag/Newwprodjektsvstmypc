plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ua.vinnitsa.power"
    compileSdk = 34
    defaultConfig { applicationId = "ua.vinnitsa.power"; minSdk = 26; targetSdk = 34; versionCode = 2; versionName = "2.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.work:work-runtime-ktx:2.9.1") }
