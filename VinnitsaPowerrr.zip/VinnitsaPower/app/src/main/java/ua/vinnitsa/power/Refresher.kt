package ua.vinnitsa.power

import android.content.Context
import androidx.work.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

object Refresher {
    val GROUPS = listOf("1.1","1.2","2.1","2.2","3.1","3.2","4.1","4.2","5.1","5.2","6.1","6.2")
    private const val BASE = "https://raw.githubusercontent.com/Svitlobot-official/timetables/main/vinnytsia/"

    /** Скачивает график очереди, пересоздаёт напоминания. Вызывать НЕ из главного потока. */
    fun refresh(c: Context): String {
        val group = Scheduler.prefs(c).getString("group", null) ?: return "Оберіть чергу"
        return try {
            val con = URL("$BASE$group.json").openConnection() as HttpURLConnection
            con.connectTimeout = 15000; con.readTimeout = 15000
            if (con.responseCode != 200) return "Помилка завантаження: HTTP ${con.responseCode} (черга $group)"
            val json = con.inputStream.bufferedReader().readText()
            val changed = Scheduler.update(c, Scheduler.parse(json))
            if (changed) Notifier.show(c, "Графік відключень змінився — нагадування оновлено")
            val now = java.time.LocalTime.now(Scheduler.KYIV).toString().take(5)
            "Черга $group, оновлено о $now"
        } catch (e: Exception) { "Помилка: ${e.message}" }
    }

    fun schedulePeriodic(c: Context) {
        val req = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("refresh", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

class RefreshWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val r = Refresher.refresh(applicationContext)
        return if (r.startsWith("Помилка")) Result.retry() else Result.success()
    }
}
