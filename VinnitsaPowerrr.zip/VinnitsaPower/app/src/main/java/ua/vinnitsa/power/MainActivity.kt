package ua.vinnitsa.power

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var list: TextView
    private lateinit var addr: EditText
    private lateinit var spin: Spinner

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val p = Scheduler.prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        addr = EditText(this).apply { hint = "Адреса (для нотатки)"; setText(p.getString("address", "")) }
        spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                Refresher.GROUPS.map { "Черга $it" })
            setSelection(Refresher.GROUPS.indexOf(p.getString("group", "1.1")).coerceAtLeast(0))
        }
        val save = Button(this).apply { text = "Зберегти й оновити"; setOnClickListener { saveAndRefresh() } }
        val bg = Button(this).apply { text = "Дозволити роботу у фоні"; setOnClickListener { allowBackground() } }
        status = TextView(this).apply { text = "—" }
        list = TextView(this)
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
                addView(addr); addView(spin); addView(save); addView(bg); addView(status); addView(list)
            })
        })
        Refresher.schedulePeriodic(this)
        if (p.getString("group", null) != null) refreshNow() else showList()
    }

    private fun saveAndRefresh() {
        Scheduler.prefs(this).edit()
            .putString("address", addr.text.toString())
            .putString("group", Refresher.GROUPS[spin.selectedItemPosition]).apply()
        Refresher.schedulePeriodic(this)
        refreshNow()
    }

    private fun refreshNow() {
        status.text = "Завантажую…"
        Thread {
            val r = Refresher.refresh(this)
            runOnUiThread { status.text = r; showList() }
        }.start()
    }

    private fun showList() {
        val up = Scheduler.upcoming(this).take(8)
        list.text = if (up.isEmpty()) "\nНайближчих подій немає" else
            "\nНайближчі події:\n" + up.joinToString("\n") {
                (if (it.second == "OFF") "🔴 вимкнення " else "🟢 увімкнення ") + Scheduler.fmt(it.first)
            }
    }

    /** Точні будильники (Android 12+) і виключення з економії батареї — інакше система може зупинити оновлення. */
    private fun allowBackground() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        else startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}
