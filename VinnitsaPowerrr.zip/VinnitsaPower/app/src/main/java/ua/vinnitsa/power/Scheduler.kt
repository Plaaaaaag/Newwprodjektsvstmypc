package ua.vinnitsa.power

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.time.*

/** Событие = момент отключения (OFF) или включения (ON). Уведомление приходит за 30 минут. */
object Scheduler {
    private const val LEAD_MIN = 30L
    val KYIV: ZoneId = ZoneId.of("Europe/Kyiv")

    fun prefs(c: Context) = c.getSharedPreferences("power", Context.MODE_PRIVATE)

    private fun toMin(s: String): Long { val p = s.split(":"); return p[0].toLong() * 60 + p[1].toLong() }
    private fun ms(t: LocalDateTime) = t.atZone(KYIV).toInstant().toEpochMilli()

    /** Разбор JSON Светлобота: days[].date + days[].outages [["02:00","07:30"],...]. Соседние интервалы склеиваются. */
    fun parse(json: String): List<Pair<LocalDateTime, LocalDateTime>> {
        val today = LocalDate.now(KYIV)
        val days = JSONObject(json).getJSONArray("days")
        val raw = mutableListOf<Pair<LocalDateTime, LocalDateTime>>()
        for (i in 0 until days.length()) {
            val d = days.getJSONObject(i)
            val date = LocalDate.parse(d.getString("date"))
            if (date.isBefore(today) || d.isNull("outages")) continue
            val arr = d.getJSONArray("outages")
            for (j in 0 until arr.length()) {
                val iv = arr.getJSONArray(j)
                raw.add(date.atStartOfDay().plusMinutes(toMin(iv.getString(0))) to
                        date.atStartOfDay().plusMinutes(toMin(iv.getString(1))))
            }
        }
        raw.sortBy { it.first }
        val merged = mutableListOf<Pair<LocalDateTime, LocalDateTime>>()
        for (iv in raw) {
            val last = merged.lastOrNull()
            if (last != null && !iv.first.isAfter(last.second)) merged[merged.size - 1] = last.first to maxOf(last.second, iv.second)
            else merged.add(iv)
        }
        return merged
    }

    private fun future(set: Set<String>): Set<String> {
        val now = System.currentTimeMillis()
        return set.filter { it.substringBefore("|").toLong() > now }.toSet()
    }

    /** Возвращает true, если будущие события изменились относительно прошлого раза. */
    fun update(c: Context, intervals: List<Pair<LocalDateTime, LocalDateTime>>): Boolean {
        val old = future(prefs(c).getStringSet("events", emptySet())!!)
        cancelAll(c)
        val set = HashSet<String>()
        for ((s, e) in intervals) { set.add("${ms(s)}|OFF"); set.add("${ms(e)}|ON") }
        prefs(c).edit().putStringSet("events", set).apply()
        scheduleAll(c)
        return old.isNotEmpty() && old != future(set)
    }

    fun upcoming(c: Context): List<Pair<Long, String>> =
        future(prefs(c).getStringSet("events", emptySet())!!)
            .map { it.substringBefore("|").toLong() to it.substringAfter("|") }.sortedBy { it.first }

    fun fmt(t: Long): String = LocalDateTime.ofInstant(Instant.ofEpochMilli(t), KYIV)
        .let { "%02d.%02d %02d:%02d".format(it.dayOfMonth, it.monthValue, it.hour, it.minute) }

    fun scheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (ev in prefs(c).getStringSet("events", emptySet())!!) {
            val t = ev.substringBefore("|").toLong(); val type = ev.substringAfter("|")
            val at = t - LEAD_MIN * 60_000
            if (at <= now) continue
            val hm = fmt(t).substringAfter(" ")
            val text = if (type == "OFF") "Через 30 хв відключать світло (о $hm)" else "Через 30 хв увімкнуть світло (о $hm)"
            val pi = pending(c, ev, text)
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (ev in prefs(c).getStringSet("events", emptySet())!!) am.cancel(pending(c, ev, ""))
    }

    private fun pending(c: Context, ev: String, text: String) = PendingIntent.getBroadcast(
        c, ev.hashCode(), Intent(c, AlarmReceiver::class.java).putExtra("text", text),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
