package ua.vinnitsa.power

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object Notifier {
    fun show(c: Context, text: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("power", "Світло", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(c, "power")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Світло").setContentText(text).setAutoCancel(true).build()
        nm.notify(System.nanoTime().toInt(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Notifier.show(c, i.getStringExtra("text") ?: "") }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.scheduleAll(c); Refresher.schedulePeriodic(c) }
}
