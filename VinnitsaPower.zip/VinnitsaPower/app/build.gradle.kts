plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "ua.vinnitsa.power"
    compileSdk = 34
    defaultConfig { applicationId = "ua.vinnitsa.power"; minSdk = 26; targetSdk = 34; versionCode = 8; versionName = "3.5" }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore"); storePassword = "android"
            keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.work:work-runtime-ktx:2.9.1") }
