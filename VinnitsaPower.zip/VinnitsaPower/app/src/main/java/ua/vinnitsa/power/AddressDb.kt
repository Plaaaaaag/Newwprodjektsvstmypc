package ua.vinnitsa.power

import android.content.Context
import org.json.JSONArray

/** База «населений пункт / вулиця / будинок → черга» з переліків ГПВ Вінницяобленерго (assets/addresses.json). */
object AddressDb {
    class Hit(val label: String, val queue: String, val exact: Boolean)
    private class Entry(
        val city: String, val ct: String, val street: String, val queue: String,
        val partial: Boolean, val ranges: List<String>, val tokens: List<String>, val initials: Set<Char>
    )

    private val STOP = setOf("вул", "вулиця", "пров", "провулок", "просп", "проспект", "бульв", "м", "смт", "с", "шосе", "район")
    private var cache: List<Entry>? = null

    private fun words(s: String): List<String> =
        s.lowercase().replace("'", "").replace("’", "").replace("ʼ", "")
            .split(Regex("[^\\p{L}0-9]+")).filter { it.isNotEmpty() && it !in STOP }

    private fun load(c: Context): List<Entry> {
        cache?.let { return it }
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(c.assets.open("addresses.json").bufferedReader().use { it.readText() })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optString("t", ""); val s = o.optString("s", "")
                val rs = ArrayList<String>()
                o.optJSONArray("r")?.let { for (k in 0 until it.length()) rs.add(it.getString(k)) }
                val w = words(s)
                out.add(Entry(o.getString("c"), o.optString("ct", ""), if (s.isEmpty()) "" else (if (t.isNotEmpty()) "$t " else "") + s,
                    o.getString("q"), o.optInt("p", 0) == 1, rs,
                    w.filter { it.length > 2 || it.any { ch -> ch.isDigit() } },
                    w.filter { it.length <= 2 && it.all { ch -> ch.isLetter() } }.map { it[0] }.toSet()))
            }
        } catch (e: Exception) { }
        cache = out
        return out
    }

    /** Населені пункти: Вінниця, Козятин, далі за алфавітом. */
    fun cities(c: Context): List<String> {
        val all = load(c).map { it.city }.distinct().sorted()
        return listOf("Вінниця", "Козятин").filter { it in all } + all.filter { it != "Вінниця" && it != "Козятин" }
    }

    /** Підказки населених пунктів за введеним текстом. */
    fun citySuggest(c: Context, text: String, limit: Int = 6): List<String> {
        val all = cities(c)
        val q = words(text)
        if (q.isEmpty()) return all.take(limit)
        return all.filter { city -> val w = words(city); q.all { t -> w.any { it.startsWith(t) } } }.take(limit)
    }

    /** Підказки вулиць населеного пункту за введеним текстом. */
    fun streetSuggest(c: Context, city: String, text: String, limit: Int = 6): List<String> {
        val q = words(text)
        if (q.isEmpty()) return emptyList()
        val main = q.maxByOrNull { it.length }!!
        return load(c).filter { it.city == city && it.street.isNotEmpty() && it.tokens.any { t -> t.startsWith(main) } &&
            q.all { t -> it.tokens.any { x -> x.startsWith(t) } || (t.isNotEmpty() && t[0] in it.initials) } }
            .map { it.street }.distinct().take(limit)
    }

    /** true, якщо в населеному пункті є вулиці (тоді потрібні вулиця й будинок). */
    fun hasStreets(c: Context, city: String): Boolean = load(c).any { it.city == city && it.street.isNotEmpty() }

    private fun houseIn(r: String, n: Int, raw: String): Boolean {
        val p = r.lowercase().split("-")
        return try {
            if (p.size == 2) n >= p[0].filter { it.isDigit() }.toInt() && n <= p[1].filter { it.isDigit() }.toInt()
            else if (p[0].any { it.isLetter() }) p[0] == raw else p[0].toInt() == n
        } catch (e: Exception) { false }
    }

    fun search(c: Context, city: String, street: String, house: String, limit: Int = 12): List<Hit> {
        val db = load(c).filter { it.city == city }
        if (db.isEmpty()) return emptyList()
        if (db.none { it.street.isNotEmpty() }) return db.map { Hit(it.ct + " " + it.city, it.queue, true) }
        val q = words(street)
        val raw = house.trim().lowercase().replace(" ", "")
        val n = raw.takeWhile { it.isDigit() }.toIntOrNull()
        if (q.isEmpty() || raw.isEmpty()) return emptyList()   // номер будинку обов'язковий
        val main = q.maxByOrNull { it.length }!!
        val ranged = ArrayList<Hit>(); val exact = ArrayList<Hit>(); val maybe = ArrayList<Hit>()
        for (e in db) {
            if (e.street.isEmpty() || e.tokens.none { it.startsWith(main) }) continue
            if (!q.all { t -> e.tokens.any { it.startsWith(t) } || (t.isNotEmpty() && t[0] in e.initials) }) continue
            val lbl = e.street + ", " + house.trim()
            when {
                e.ranges.isNotEmpty() -> if (n != null && e.ranges.any { houseIn(it, n, raw) }) ranged.add(Hit(lbl, e.queue, true))
                e.partial -> maybe.add(Hit("$lbl (частково)", e.queue, false))
                else -> exact.add(Hit(lbl, e.queue, true))
            }
        }
        return (ranged + exact + maybe).take(limit)
    }
}
