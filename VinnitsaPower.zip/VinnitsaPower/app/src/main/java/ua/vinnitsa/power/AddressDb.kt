package ua.vinnitsa.power

import android.content.Context
import org.json.JSONArray

/** База «вулиця Вінниці → черга» з переліку ГПВ Вінницяобленерго (assets/addresses.json). */
object AddressDb {
    class Hit(val label: String, val queue: String, val exact: Boolean)
    private class Entry(
        val label: String, val queue: String, val partial: Boolean, val ranges: List<String>,
        val tokens: List<String>, val initials: Set<Char>
    )

    private val STOP = setOf("вул", "вулиця", "пров", "провулок", "просп", "проспект", "бульв", "м", "смт", "с", "шосе", "район")
    private var cache: List<Entry>? = null

    private fun words(s: String): List<String> =
        s.lowercase().replace("'", "").replace("’", "").replace("ʼ", "")
            .split(Regex("[^\\p{L}0-9]+")).filter { it.isNotEmpty() && it !in STOP }

    private fun load(c: Context): List<Entry> {
        cache?.let { return it }
        val out = ArrayList<Entry>()
        try {
            val arr = JSONArray(c.assets.open("addresses.json").bufferedReader().use { it.readText() })
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optString("t", ""); val s = o.getString("s")
                val rs = ArrayList<String>()
                o.optJSONArray("r")?.let { for (k in 0 until it.length()) rs.add(it.getString(k)) }
                val w = words(s)
                out.add(Entry((if (t.isNotEmpty()) "$t " else "") + s, o.getString("q"), o.optInt("p", 0) == 1, rs,
                    w.filter { it.length > 2 || it.any { ch -> ch.isDigit() } },
                    w.filter { it.length <= 2 && it.all { ch -> ch.isLetter() } }.map { it[0] }.toSet()))
            }
        } catch (e: Exception) { }
        cache = out
        return out
    }

    private fun houseIn(r: String, n: Int, raw: String): Boolean {
        val p = r.lowercase().split("-")
        return try {
            if (p.size == 2) n >= p[0].filter { it.isDigit() }.toInt() && n <= p[1].filter { it.isDigit() }.toInt()
            else if (p[0].any { it.isLetter() }) p[0] == raw else p[0].toInt() == n
        } catch (e: Exception) { false }
    }

    fun search(c: Context, street: String, house: String, limit: Int = 12): List<Hit> {
        val q = words(street)
        if (q.isEmpty()) return emptyList()
        val raw = house.trim().lowercase().replace(" ", "")
        val n = raw.takeWhile { it.isDigit() }.toIntOrNull()
        val main = q.maxByOrNull { it.length }!!   // прізвище/назва: має збігтися реально, не через ініціал
        val ranged = ArrayList<Hit>(); val exact = ArrayList<Hit>(); val maybe = ArrayList<Hit>()
        for (e in load(c)) {
            if (e.tokens.none { it.startsWith(main) }) continue
            if (!q.all { t -> e.tokens.any { it.startsWith(t) } || (t.isNotEmpty() && t[0] in e.initials) }) continue
            when {
                e.ranges.isNotEmpty() -> {
                    if (n == null) ranged.add(Hit(e.label + " (буд. " + e.ranges.joinToString(", ") + ")", e.queue, true))
                    else if (e.ranges.any { houseIn(it, n, raw) }) ranged.add(Hit(e.label + ", " + house.trim(), e.queue, true))
                }
                e.partial -> maybe.add(Hit(e.label + " (частково)", e.queue, false))
                else -> exact.add(Hit(e.label + (if (n != null) ", " + house.trim() else ""), e.queue, true))
            }
        }
        return (ranged + exact + maybe).take(limit)
    }
}
