package ua.vinnitsa.power

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.TreeMap

/** Дата -> интервалы отключений в минутах от начала суток [start, end]. */
typealias Days = TreeMap<LocalDate, List<IntArray>>

object Scheduler {
    val KYIV: ZoneId = try { ZoneId.of("Europe/Kyiv") } catch (e: Exception) { ZoneId.of("Europe/Kiev") }

    fun prefs(c: Context) = c.getSharedPreferences("power", Context.MODE_PRIVATE)

    // ---------- данные ----------
    fun loadDays(c: Context): Days {
        val out = Days()
        val s = prefs(c).getString("days", null) ?: return out
        try {
            val o = JSONObject(s)
            for (k in o.keys()) {
                val arr = o.getJSONArray(k)
                val list = ArrayList<IntArray>()
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONArray(i); list.add(intArrayOf(p.getInt(0), p.getInt(1)))
                }
                out[LocalDate.parse(k)] = list
            }
        } catch (e: Exception) { }
        return out
    }

    private fun saveDays(c: Context, d: Days) {
        val o = JSONObject()
        for ((k, v) in d) {
            val a = JSONArray()
            for (iv in v) a.put(JSONArray().put(iv[0]).put(iv[1]))
            o.put(k.toString(), a)
        }
        prefs(c).edit().putString("days", o.toString()).apply()
    }

    private fun toMin(s: String): Int { val p = s.split(":"); return p[0].toInt() * 60 + p[1].toInt() }

    /** Разбор JSON Светлобота: days[].date + days[].outages [["02:00","07:30"],...]. */
    fun parseSvitlobot(json: String): Days {
        val today = LocalDate.now(KYIV)
        val out = Days()
        val days = JSONObject(json).getJSONArray("days")
        for (i in 0 until days.length()) {
            val d = days.getJSONObject(i)
            val date = LocalDate.parse(d.getString("date"))
            if (date.isBefore(today) || d.isNull("outages")) continue
            val arr = d.getJSONArray("outages")
            val list = ArrayList<IntArray>()
            for (j in 0 until arr.length()) {
                val iv = arr.getJSONArray(j)
                list.add(intArrayOf(toMin(iv.getString(0)), toMin(iv.getString(1))))
            }
            out[date] = list
        }
        return out
    }

    private fun at(date: LocalDate, min: Int): Long =
        date.atStartOfDay().plusMinutes(min.toLong()).atZone(KYIV).toInstant().toEpochMilli()

    /** Склеенные интервалы в epoch ms (через полночь тоже). */
    fun intervals(days: Days): List<Pair<Long, Long>> {
        val raw = ArrayList<Pair<Long, Long>>()
        for ((date, list) in days) for (iv in list) raw.add(at(date, iv[0]) to at(date, iv[1]))
        raw.sortBy { it.first }
        val m = ArrayList<Pair<Long, Long>>()
        for (iv in raw) {
            val l = m.lastOrNull()
            if (l != null && iv.first <= l.second) m[m.size - 1] = l.first to maxOf(l.second, iv.second) else m.add(iv)
        }
        return m
    }

    class State(val off: Boolean, val changeAt: Long?, val laterStart: Long?)

    fun state(c: Context): State? {
        val days = loadDays(c)
        if (days.isEmpty()) return null
        val iv = intervals(days)
        val now = System.currentTimeMillis()
        val cur = iv.firstOrNull { now >= it.first && now < it.second }
        if (cur != null) return State(true, cur.second, iv.firstOrNull { it.first > cur.second }?.first)
        return State(false, iv.firstOrNull { it.first > now }?.first, null)
    }

    fun minutesOff(list: List<IntArray>?): Int? {
        if (list == null) return null
        var s = 0
        for (p in list) s += p[1] - p[0]
        return s
    }

    // ---------- форматирование ----------
    fun hm(t: Long): String { val z = Instant.ofEpochMilli(t).atZone(KYIV); return "%02d:%02d".format(z.hour, z.minute) }

    fun whenText(t: Long): String {
        val d = Instant.ofEpochMilli(t).atZone(KYIV).toLocalDate()
        val today = LocalDate.now(KYIV)
        val s = hm(t)
        return when (d) {
            today -> s
            today.plusDays(1) -> "$s (завтра)"
            else -> "$s (%02d.%02d)".format(d.dayOfMonth, d.monthValue)
        }
    }

    fun leadText(m: Int): String = when {
        m < 60 -> "$m хв"
        m % 60 == 0 -> "${m / 60} год"
        else -> "${m / 60} год ${m % 60} хв"
    }

    fun dur(ms: Long): String {
        val m = (ms / 60000).coerceAtLeast(0)
        val h = m / 60; val mm = m % 60
        return if (h == 0L) "$mm хв" else if (mm == 0L) "$h год" else "$h год $mm хв"
    }

    // ---------- настройки сповіщень ----------
    fun notifOn(c: Context, off: Boolean) = prefs(c).getBoolean(if (off) "notif_off" else "notif_on", true)
    fun lead(c: Context, off: Boolean) = prefs(c).getInt(if (off) "lead_off" else "lead_on", 30)

    // ---------- события и будильники ----------
    private fun futureEvents(c: Context): Set<String> {
        val now = System.currentTimeMillis()
        return prefs(c).getStringSet("events", emptySet())!!.filter { it.substringBefore("|").toLong() > now }.toSet()
    }

    /** Сохраняет график, пересоздаёт будильники. true — если будущие события изменились. */
    fun update(c: Context, days: Days): Boolean {
        val old = futureEvents(c)
        cancelAll(c)
        saveDays(c, days)
        val set = HashSet<String>()
        // Полночь после последнего опубликованного дня — не «включение»: завтрашний график может быть ещё не опубликован.
        val edge = if (days.isEmpty()) -1L else at(days.lastKey(), 1440)
        for ((s, e) in intervals(days)) {
            set.add("$s|OFF")
            if (e != edge) set.add("$e|ON")
        }
        prefs(c).edit().putStringSet("events", set).apply()
        scheduleAll(c)
        return old.isNotEmpty() && old != futureEvents(c)
    }

    fun scheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (ev in prefs(c).getStringSet("events", emptySet())!!) {
            val t = ev.substringBefore("|").toLong()
            val off = ev.endsWith("OFF")
            val lead = lead(c, off)
            val pi = pending(c, ev, off, lead, t)
            val alarmAt = t - lead * 60_000L
            if (!notifOn(c, off) || alarmAt <= now) { am.cancel(pi); continue }
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmAt, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmAt, pi)
        }
    }

    private fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (ev in prefs(c).getStringSet("events", emptySet())!!) am.cancel(pending(c, ev, true, 0, 0))
    }

    private fun pending(c: Context, ev: String, off: Boolean, lead: Int, t: Long): PendingIntent {
        val title = if (off) "Відключення світла" else "Увімкнення світла"
        val text = "Через ${leadText(lead)} " + (if (off) "відключать" else "увімкнуть") + " світло (о ${hm(t)})"
        val i = Intent(c, AlarmReceiver::class.java).putExtra("title", title).putExtra("text", text)
        return PendingIntent.getBroadcast(c, ev.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
