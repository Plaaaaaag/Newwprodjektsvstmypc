package ua.vinnitsa.power

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Build
import android.media.RingtoneManager

object Notifier {
    const val CH = "alerts_v5"
    private val OLD = listOf("alerts", "alerts_v1", "alerts_v2", "alerts_v3", "alerts_v4")

    fun ensure(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        // старые каналы без звука удаляем: звук канала после создания изменить нельзя
        for (o in OLD) if (nm.getNotificationChannel(o) != null) nm.deleteNotificationChannel(o)
        if (nm.getNotificationChannel(CH) != null) return
        val ch = NotificationChannel(CH, "Сповіщення про світло", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Попередження про відключення та увімкнення світла"
        ch.enableVibration(true)
        ch.vibrationPattern = longArrayOf(0, 350, 150, 350)
        ch.enableLights(true)
        ch.lightColor = Color.RED
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        // системний звук сповіщень за замовчуванням (змінюється кнопкою «Звук» або в налаштуваннях телефону)
        val sound = android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
        ch.setSound(
            sound,
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        )
        nm.createNotificationChannel(ch)
    }

    /** Причина, чому сповіщення можуть бути беззвучними (null — все гаразд). */
    fun problem(c: Context): String? {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return "Сповіщення для застосунку вимкнені в налаштуваннях телефону"
        ensure(c)
        val ch = nm.getNotificationChannel(CH)
        if (ch == null || ch.importance == NotificationManager.IMPORTANCE_NONE) return "Канал сповіщень вимкнено — натисніть «Звук»"
        if (ch.sound == null || ch.importance < NotificationManager.IMPORTANCE_DEFAULT) return "Звук каналу вимкнено — натисніть «Звук» і ввімкніть його"
        val f = nm.currentInterruptionFilter
        if (f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
            return "Увімкнено режим «Не турбувати» — він вимикає звук"
        val am = c.getSystemService(AudioManager::class.java)
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return "Телефон у беззвучному або вібро-режимі"
        if (am.getStreamVolume(AudioManager.STREAM_NOTIFICATION) == 0) return "Гучність сповіщень виставлена на нуль"
        if (Build.VERSION.SDK_INT >= 31 && !c.getSystemService(android.app.AlarmManager::class.java).canScheduleExactAlarms())
            return "Не дозволено точні будильники — нагадування можуть спізнюватись"
        return null
    }

    fun show(c: Context, title: String, text: String) {
        ensure(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFA855F7.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((System.nanoTime() and 0x7fffffff).toInt(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.show(c, i.getStringExtra("title") ?: "Світло", i.getStringExtra("text") ?: "")
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.scheduleAll(c)
        Refresher.schedulePeriodic(c)
    }
}
