package ua.vinnitsa.power

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.RingtoneManager

object Notifier {
    const val CH = "alerts_v3"
    private val OLD = listOf("alerts", "alerts_v1", "alerts_v2")

    fun ensure(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        // старые каналы без звука удаляем: звук канала после создания изменить нельзя
        for (o in OLD) if (nm.getNotificationChannel(o) != null) nm.deleteNotificationChannel(o)
        if (nm.getNotificationChannel(CH) != null) return
        val ch = NotificationChannel(CH, "Сповіщення про світло", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Попередження про відключення та увімкнення світла"
        ch.enableVibration(true)
        ch.vibrationPattern = longArrayOf(0, 350, 150, 350)
        ch.enableLights(true)
        ch.lightColor = Color.RED
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        val sound = RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ch.setSound(
            sound,
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        )
        nm.createNotificationChannel(ch)
    }

    fun show(c: Context, title: String, text: String) {
        ensure(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setColor(0xFFA855F7.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((System.nanoTime() and 0x7fffffff).toInt(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.show(c, i.getStringExtra("title") ?: "Світло", i.getStringExtra("text") ?: "")
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.scheduleAll(c)
        Refresher.schedulePeriodic(c)
    }
}
