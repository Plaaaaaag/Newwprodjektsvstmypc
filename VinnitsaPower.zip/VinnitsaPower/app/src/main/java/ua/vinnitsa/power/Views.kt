package ua.vinnitsa.power

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Random

/** Фон: красные точки, медленно падающие вниз. */
class RainView(ctx: Context) : View(ctx) {
    private class Dot(var x: Float, var y: Float, val r: Float, val v: Float, val a: Int)

    private val d = ctx.resources.displayMetrics.density
    private val rnd = Random()
    private val dots = ArrayList<Dot>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var last = 0L

    private fun newDot(anyY: Boolean) = Dot(
        rnd.nextFloat() * width,
        if (anyY) rnd.nextFloat() * height else -20f * d,
        (1.4f + rnd.nextFloat() * 2.6f) * d,
        (0.6f + rnd.nextFloat() * 1.6f) * d,
        50 + rnd.nextInt(130)
    )

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        dots.clear()
        if (w > 0 && h > 0) repeat(42) { dots.add(newDot(true)) }
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 16f else ((now - last) / 1_000_000f).coerceIn(1f, 50f)
        last = now
        for (i in dots.indices) {
            val dot = dots[i]
            dot.y += dot.v * dt / 16f
            if (dot.y - dot.r > height) { dots[i] = newDot(false); continue }
            // шлейф
            for (k in 1..3) {
                p.color = Color.argb(dot.a / (k + 1), 255, 60, 60)
                c.drawCircle(dot.x, dot.y - k * dot.r * 2.2f, dot.r * (1f - k * 0.2f), p)
            }
            p.color = Color.argb(dot.a / 3, 255, 40, 40)
            c.drawCircle(dot.x, dot.y, dot.r * 2.2f, p)
            p.color = Color.argb(dot.a + 40, 255, 80, 80)
            c.drawCircle(dot.x, dot.y, dot.r, p)
        }
        postInvalidateOnAnimation()
    }
}

/** Сетка графика: слева часы, дальше колонки дней (сегодня, завтра). */
class ScheduleView(ctx: Context) : View(ctx) {
    class Col(val title: String, val sub: String, val intervals: List<IntArray>?)

    var cols: List<Col> = emptyList()
    var nowMin: Int = -1

    private val d = ctx.resources.displayMetrics.density
    private val labelW = 96f * d
    private val headH = 56f * d
    private val rowH = 34f * d
    private val gap = 8f * d
    private val rad = 9f * d
    private val rect = RectF()

    private fun paint(color: Int, size: Float = 0f, bold: Boolean = false, center: Boolean = false) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            if (size > 0f) textSize = size * d
            if (bold) typeface = Typeface.DEFAULT_BOLD
            if (center) textAlign = Paint.Align.CENTER
        }

    private val pLabel = paint(0xFFB8AEDB.toInt(), 12.5f)
    private val pLabelNow = paint(Color.WHITE, 12.5f, bold = true)
    private val pTitle = paint(Color.WHITE, 15f, bold = true, center = true)
    private val pSub = paint(0xFF8F86B3.toInt(), 11.5f, center = true)
    private val pCell = paint(0xFF1A1330.toInt())
    private val pOff = paint(0xFFFF5A36.toInt())
    private val pEmpty = paint(0xFF6F668F.toInt(), 11f, center = true)
    private val pNow = paint(0xFFA78BFA.toInt()).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f * d }
    private val pLine = paint(Color.WHITE).apply { strokeWidth = 2f * d }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (headH + rowH * 24 + 8f * d).toInt())
    }

    private fun baseline(p: Paint, cy: Float): Float = cy - (p.fontMetrics.ascent + p.fontMetrics.descent) / 2f

    override fun onDraw(c: Canvas) {
        val n = cols.size.coerceAtLeast(1)
        val colW = (width - labelW - gap * n) / n
        val nowHour = if (nowMin >= 0) nowMin / 60 else -1

        for ((i, col) in cols.withIndex()) {
            val cx = labelW + gap + i * (colW + gap) + colW / 2
            c.drawText(col.title, cx, headH * 0.42f, pTitle)
            c.drawText(col.sub, cx, headH * 0.74f, pSub)
        }

        for (h in 0 until 24) {
            val top = headH + h * rowH
            val cy = top + rowH / 2
            val label = "%02d:00 – %02d:00".format(h, h + 1)
            c.drawText(label, 10f * d, baseline(pLabel, cy), if (h == nowHour) pLabelNow else pLabel)

            for ((i, col) in cols.withIndex()) {
                val x = labelW + gap + i * (colW + gap)
                rect.set(x, top + 2f * d, x + colW, top + rowH - 2f * d)
                c.drawRoundRect(rect, rad, rad, pCell)
                val ivs = col.intervals ?: continue
                for (iv in ivs) {
                    val s = maxOf(iv[0], h * 60); val e = minOf(iv[1], h * 60 + 60)
                    if (e > s) {
                        rect.set(x + (s - h * 60) / 60f * colW, top + 2f * d, x + (e - h * 60) / 60f * colW, top + rowH - 2f * d)
                        c.drawRoundRect(rect, rad, rad, pOff)
                    }
                }
            }
        }

        for ((i, col) in cols.withIndex()) {
            if (col.intervals != null) continue
            val cx = labelW + gap + i * (colW + gap) + colW / 2
            c.drawText("графік ще", cx, headH + rowH * 11.6f, pEmpty)
            c.drawText("не опубліковано", cx, headH + rowH * 12.4f, pEmpty)
        }

        if (nowHour in 0..23) {
            val top = headH + nowHour * rowH
            rect.set(3f * d, top, width - 3f * d, top + rowH)
            c.drawRoundRect(rect, rad + 2f * d, rad + 2f * d, pNow)
            if (cols.isNotEmpty()) {
                val x = labelW + gap + (nowMin % 60) / 60f * colW
                c.drawLine(x, top + 3f * d, x, top + rowH - 3f * d, pLine)
            }
        }
    }
}
