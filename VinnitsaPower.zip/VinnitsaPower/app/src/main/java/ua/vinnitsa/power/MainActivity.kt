package ua.vinnitsa.power

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.time.LocalDate
import java.time.ZonedDateTime

private object Pal {
    val GRAY = 0xFF9A93BD.toInt()
    val GREEN = 0xFF4ADE80.toInt()
    val RED = 0xFFFF5C5C.toInt()
    val WHITE = Color.WHITE
}

private class Scraped(val masks: Map<LocalDate, BooleanArray>, val days: Days, val queue: String?, var addr: String)

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var rain: RainView
    private lateinit var holder: FrameLayout
    private lateinit var web: WebView
    private var onAddress = false
    private var saving = false
    private var tickAction: (() -> Unit)? = null
    private val chosen = booleanArrayOf(false, false, false)
    private val fieldEt = arrayOfNulls<EditText>(3)
    private val sugBox = arrayOfNulls<LinearLayout>(3)
    private val typeRun = arrayOfNulls<Runnable>(3)
    private var suppress = false
    private var tvStatus: TextView? = null
    private var pollTries = 0

    private val tick = object : Runnable {
        override fun run() { tickAction?.invoke(); ui.postDelayed(this, 30_000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notifier.ensure(this)
        rain = RainView(this)
        holder = FrameLayout(this)
        web = makeWeb()
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val cover = View(this)
        cover.setBackgroundColor(0xFF0A0612.toInt())
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))
        root.addView(rain, FrameLayout.LayoutParams(-1, -1))
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        Refresher.schedulePeriodic(this)
        if (Scheduler.prefs(this).getString("address", null) == null) showAddress() else showMain()
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleAll(this)
        if (!onAddress && tickAction != null) { ui.removeCallbacks(tick); ui.post(tick) }
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val has = Scheduler.prefs(this).getString("address", null) != null
        if (onAddress && has) showMain()
        else super.onBackPressed()
    }

    // ================= UI-хелперы =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.textSize = sp; tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.setColor(0xCC141022.toInt()); bg.cornerRadius = dpf(22f); bg.setStroke(dp(1), 0x33A78BFA)
        l.background = bg
        l.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        return l
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val shape = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (filled) intArrayOf(0xFF7C3AED.toInt(), 0xFFB05CF6.toInt()) else intArrayOf(0x1AFFFFFF, 0x1AFFFFFF)
        )
        shape.cornerRadius = dpf(18f)
        if (!filled) shape.setStroke(dp(1), 0x66A78BFA)
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE); mask.cornerRadius = dpf(18f)
        val t = TextView(this)
        t.text = text; t.textSize = 15f; t.setTextColor(Color.WHITE); t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(14), dp(14), dp(14))
        t.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape, mask)
        t.isClickable = true
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        return t
    }

    private fun dayTitle(d: LocalDate): String {
        val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
        return names[d.dayOfWeek.value - 1] + " %02d.%02d".format(d.dayOfMonth, d.monthValue)
    }

    // ================= Головний екран =================
    private fun showMain() {
        onAddress = false
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val p = Scheduler.prefs(this)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ico = ImageView(this)
        ico.setImageResource(R.mipmap.ic_launcher)
        head.addView(ico, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(label("VoltAlert", 24f, Pal.WHITE, true))
        titles.addView(label(p.getString("address", "") ?: "", 13f, Pal.GRAY))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(head)

        // статус
        val statusCard = card()
        val tvState = label("", 26f, Pal.WHITE, true)
        val tvSub = label("", 14f, Pal.GRAY)
        statusCard.addView(tvState); statusCard.addView(tvSub)
        col.addView(statusCard)

        // график
        val sv = ScheduleView(this)

        fun updateStatus() {
            val st = Scheduler.state(this)
            if (st == null) {
                tvState.text = "Немає даних"; tvState.setTextColor(Pal.GRAY)
                tvSub.text = "Натисніть «Оновити»"
                return
            }
            val now = System.currentTimeMillis()
            val at = st.changeAt
            if (st.off) {
                tvState.text = "Світла немає"; tvState.setTextColor(Pal.RED)
                tvSub.text = if (at != null) "Увімкнуть о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Час увімкнення невідомий"
            } else {
                tvState.text = "Світло є"; tvState.setTextColor(Pal.GREEN)
                tvSub.text = if (at != null) "Відключення о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Найближчих відключень немає"
            }
        }

        fun renderSchedule() {
            val days = Scheduler.loadDays(this)
            val today = LocalDate.now(Scheduler.KYIV)
            val tom = today.plusDays(1)
            sv.cols = listOf(
                ScheduleView.Col(dayTitle(today), "сьогодні", days[today]),
                ScheduleView.Col(dayTitle(tom), "завтра", days[tom])
            )
            val z = ZonedDateTime.now(Scheduler.KYIV)
            sv.nowMin = z.hour * 60 + z.minute
            sv.invalidate()
        }

        val tvUpdated = label(p.getString("updated", "") ?: "", 12f, Pal.GRAY)
        tvUpdated.gravity = Gravity.CENTER
        tvUpdated.setPadding(0, dp(10), 0, 0)

        // кнопки
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val bCalc = button("Розрахувати час", true) { showCalc() }
        val bRefresh = button("Оновити", false) {
            tvUpdated.text = "Оновлення…"
            refreshNow { r -> tvUpdated.text = r }
        }
        (bCalc.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bRefresh.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        row.addView(bCalc); row.addView(bRefresh)
        col.addView(row)

        // графік-картка
        val gCard = card()
        gCard.addView(label("Графік відключень", 17f, Pal.WHITE, true))
        val legend = SpannableStringBuilder("■ немає світла     ■ є світло")
        legend.setSpan(ForegroundColorSpan(0xFFFF5A36.toInt()), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        legend.setSpan(ForegroundColorSpan(0xFF3A2F5E.toInt()), 17, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tvLegend = label("", 12f, Pal.GRAY)
        tvLegend.text = legend
        tvLegend.setPadding(0, dp(4), 0, dp(10))
        gCard.addView(tvLegend)
        gCard.addView(sv, LinearLayout.LayoutParams(-1, -2))
        col.addView(gCard)

        // сповіщення
        val nCard = card()
        nCard.addView(label("Сповіщення", 17f, Pal.WHITE, true))
        notifBlock(nCard, "Про відключення", true)
        notifBlock(nCard, "Про увімкнення", false)
        val soundRow = LinearLayout(this)
        soundRow.orientation = LinearLayout.HORIZONTAL
        val bTest = button("Перевірити", false) {
            Notifier.show(this, "Перевірка", "Так звучатимуть попередження про світло")
        }
        val bSound = button("Звук", false) {
            Notifier.ensure(this)
            try {
                startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH)
                )
            } catch (e: Exception) { }
        }
        (bTest.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bSound.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        soundRow.addView(bTest); soundRow.addView(bSound)
        nCard.addView(soundRow)
        nCard.addView(button("Робота у фоні", false) { setupBackground() })
        col.addView(nCard)

        col.addView(button("Змінити адресу", false) { showAddress() })
        col.addView(tvUpdated)

        tickAction = { updateStatus(); renderSchedule() }
        tickAction?.invoke()
        ui.removeCallbacks(tick); ui.post(tick)
        refreshNow { r -> tvUpdated.text = r }
    }

    private val leads = intArrayOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240)

    private fun notifBlock(parent: LinearLayout, title: String, off: Boolean) {
        val p = Scheduler.prefs(this)
        val kEn = if (off) "notif_off" else "notif_on"
        val kLead = if (off) "lead_off" else "lead_on"
        val enabled = p.getBoolean(kEn, true)

        val sw = Switch(this)
        sw.text = title; sw.textSize = 16f; sw.setTextColor(Color.WHITE); sw.isChecked = enabled
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFC4B5FD.toInt(), 0xFF9CA3AF.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x887C3AED.toInt(), 0x44FFFFFF))
        sw.setPadding(0, dp(12), 0, dp(4))

        val sp = Spinner(this)
        val labels = leads.map { "За " + Scheduler.leadText(it) }
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        val cur = p.getInt(kLead, 30)
        sp.setSelection(leads.indexOf(cur).let { if (it < 0) 4 else it }, false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (leads[pos] != p.getInt(kLead, 30)) {
                    p.edit().putInt(kLead, leads[pos]).apply()
                    Scheduler.scheduleAll(this@MainActivity)
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) { }
        }
        sp.isEnabled = enabled; sp.alpha = if (enabled) 1f else 0.4f
        sw.setOnCheckedChangeListener { _, on ->
            p.edit().putBoolean(kEn, on).apply()
            sp.isEnabled = on; sp.alpha = if (on) 1f else 0.4f
            Scheduler.scheduleAll(this)
        }

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.addView(label("Попередити", 14f, Pal.GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(sp, LinearLayout.LayoutParams(-2, -2))
        parent.addView(sw, LinearLayout.LayoutParams(-1, -2))
        parent.addView(line, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshNow(done: ((String) -> Unit)? = null) {
        Thread {
            val r = Refresher.refresh(this, false)
            runOnUiThread { if (!isFinishing) { done?.invoke(r); tickAction?.invoke() } }
        }.start()
    }

    private fun showCalc() {
        val days = Scheduler.loadDays(this)
        val st = Scheduler.state(this)
        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        if (st == null) {
            sb.append("Даних про графік ще немає.")
        } else {
            val at = st.changeAt
            if (st.off) {
                sb.append("Зараз світла немає.\n")
                if (at != null) sb.append("Увімкнуть о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                val later = st.laterStart
                if (later != null) sb.append("Потім відключення о ${Scheduler.whenText(later)}.\n")
            } else {
                sb.append("Зараз світло є.\n")
                if (at != null) sb.append("Відключення о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                else sb.append("Найближчих відключень немає.\n")
            }
        }
        val today = LocalDate.now(Scheduler.KYIV)
        fun total(d: LocalDate): String {
            val m = Scheduler.minutesOff(days[d]) ?: return "графік ще не опубліковано"
            return Scheduler.dur(m * 60_000L)
        }
        sb.append("\nБез світла сьогодні: ").append(total(today))
        sb.append("\nБез світла завтра: ").append(total(today.plusDays(1)))
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Розрахунок часу")
            .setMessage(sb.toString())
            .setPositiveButton("Добре", null)
            .show()
    }

    private fun setupBackground() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                return
            }
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
            Toast.makeText(this, "Усе налаштовано ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    // ================= Екран адреси (поля в застосунку, сайт VOE прихований) =================
    private fun makeWeb(): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) { v.evaluateJavascript(VA_JS, null) }
        }
        return w
    }

    private fun q(s: String): String = JSONObject.quote(s)

    private fun decode(raw: String?): String? = try {
        val v = JSONTokener(raw ?: "null").nextValue()
        if (v is String) v else null
    } catch (e: Exception) { null }

    /** Виконує JS на прихованій сторінці VOE (спочатку гарантує наявність драйвера). */
    private fun js(code: String, cb: ((String?) -> Unit)? = null) {
        web.evaluateJavascript(VA_JS, null)
        web.evaluateJavascript(code) { cb?.invoke(it) }
    }

    private fun showAddress() {
        onAddress = true; saving = false
        ui.removeCallbacks(tick)
        for (i in 0..2) { chosen[i] = false; typeRun[i]?.let { ui.removeCallbacks(it) } }
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val hasAddr = Scheduler.prefs(this).getString("address", null) != null

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(label("Ваша адреса", 26f, Pal.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (hasAddr) {
            val close = button("Назад", false) { showMain() }
            (close.layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0; width = -2 }
            close.setPadding(dp(20), dp(8), dp(20), dp(8))
            bar.addView(close)
        }
        col.addView(bar)

        val c = card()
        fieldBlock(c, 0, "Населений пункт", "Почніть вводити назву")
        fieldBlock(c, 1, "Вулиця", "Спочатку оберіть населений пункт")
        fieldBlock(c, 2, "Будинок", "Номер будинку")
        col.addView(c)

        val st = label("", 14f, Pal.GRAY)
        st.setPadding(dp(4), dp(12), dp(4), 0)
        tvStatus = st
        col.addView(st)
        col.addView(button("Перевірити адресу", true) { submitAddress() })

        val man = label("Не виходить? Обрати графік вручну", 13f, 0xFFA78BFA.toInt())
        man.gravity = Gravity.CENTER
        man.setPadding(0, dp(18), 0, 0)
        man.setOnClickListener { manualGroup() }
        col.addView(man)
        val diag = label("Надіслати діагностику", 12f, Pal.GRAY)
        diag.gravity = Gravity.CENTER
        diag.setPadding(0, dp(14), 0, 0)
        diag.setOnClickListener { copyDiag() }
        col.addView(diag)

        web.loadUrl(URL)
    }

    private fun fieldBlock(parent: LinearLayout, idx: Int, title: String, hint: String) {
        val t = label(title, 13f, Pal.GRAY)
        t.setPadding(dp(2), if (idx == 0) 0 else dp(14), 0, dp(6))
        parent.addView(t)

        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(0x66FFFFFF)
        et.setTextColor(Color.WHITE)
        et.textSize = 16f
        et.setSingleLine(true)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(0xFF1A1330.toInt()); bg.cornerRadius = dpf(14f); bg.setStroke(dp(1), 0x44A78BFA)
        et.background = bg
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun afterTextChanged(s: Editable?) { if (!suppress) onType(idx, s?.toString() ?: "") }
        })
        parent.addView(et, LinearLayout.LayoutParams(-1, -2))

        val sug = LinearLayout(this)
        sug.orientation = LinearLayout.VERTICAL
        sug.visibility = View.GONE
        val sbg = GradientDrawable()
        sbg.setColor(0xFF211A3A.toInt()); sbg.cornerRadius = dpf(14f)
        sug.background = sbg
        parent.addView(sug, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        fieldEt[idx] = et; sugBox[idx] = sug
    }

    private fun setField(idx: Int, text: String) {
        suppress = true
        fieldEt[idx]?.setText(text)
        fieldEt[idx]?.setSelection(text.length)
        suppress = false
    }

    private fun onType(idx: Int, text: String) {
        chosen[idx] = false
        for (j in idx + 1..2) {
            if (fieldEt[j]?.text?.isNotEmpty() == true) setField(j, "")
            chosen[j] = false
            sugBox[j]?.visibility = View.GONE
        }
        sugBox[idx]?.visibility = View.GONE
        typeRun[idx]?.let { ui.removeCallbacks(it) }
        val need = if (idx == 2) 1 else 2
        if (text.trim().length < need) return
        if (idx > 0 && !chosen[idx - 1]) {
            tvStatus?.text = "Спершу оберіть попередній пункт зі списку підказок"
            return
        }
        tvStatus?.text = ""
        val r = Runnable { driveType(idx, text) }
        typeRun[idx] = r
        ui.postDelayed(r, 250)
    }

    private fun driveType(idx: Int, text: String) {
        js("window.__va.type($idx,${q(text)})") { r ->
            if (decode(r) == "noinput") {
                tvStatus?.text = "Сервіс ще завантажується… спробуйте за кілька секунд"
            } else {
                ui.postDelayed({ readSuggestions(idx, text, 0) }, 250)
            }
        }
    }

    private fun readSuggestions(idx: Int, text: String, attempt: Int) {
        if (!onAddress || fieldEt[idx]?.text?.toString() != text) return
        js("window.__va.read($idx)") { r ->
            val all = try { JSONArray(decode(r) ?: "[]") } catch (e: Exception) { JSONArray() }
            // відсікаємо застарілі підказки від попереднього символу
            val words = text.lowercase().split(" ").filter { it.isNotEmpty() }
            val ok = JSONArray()
            for (i in 0 until all.length()) {
                val t = all.getString(i).lowercase()
                if (words.all { t.contains(it) }) ok.put(all.getString(i))
            }
            when {
                ok.length() > 0 -> showSuggestions(idx, ok)
                all.length() > 0 && attempt >= 6 -> showSuggestions(idx, all)
                attempt < 14 -> ui.postDelayed({ readSuggestions(idx, text, attempt + 1) }, 250)
                else -> showSuggestions(idx, JSONArray())
            }
        }
    }

    private fun showSuggestions(idx: Int, arr: JSONArray) {
        val box = sugBox[idx] ?: return
        box.removeAllViews()
        if (arr.length() == 0) {
            if (idx < 2) tvStatus?.text = "Нічого не знайдено — перевірте назву"
            box.visibility = View.GONE
            return
        }
        for (i in 0 until arr.length()) {
            val t = arr.getString(i)
            val row = TextView(this)
            row.text = t; row.textSize = 15f; row.setTextColor(Color.WHITE)
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            val mask = GradientDrawable()
            mask.setColor(Color.WHITE); mask.cornerRadius = dpf(14f)
            row.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), null, mask)
            row.isClickable = true
            row.setOnClickListener { pick(idx, i, t) }
            box.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        box.visibility = View.VISIBLE
    }

    private fun pick(idx: Int, i: Int, text: String) {
        js("window.__va.pick($idx,$i)")
        setField(idx, text)
        chosen[idx] = true
        sugBox[idx]?.visibility = View.GONE
        tvStatus?.text = ""
        if (idx < 2) fieldEt[idx + 1]?.requestFocus()
    }

    private fun submitAddress() {
        if (saving) return
        val city = fieldEt[0]?.text?.toString()?.trim() ?: ""
        val street = fieldEt[1]?.text?.toString()?.trim() ?: ""
        val house = fieldEt[2]?.text?.toString()?.trim() ?: ""
        if (!chosen[0] || !chosen[1] || !chosen[2]) {
            Toast.makeText(this, "Оберіть населений пункт, вулицю й будинок зі списку підказок", Toast.LENGTH_LONG).show()
            return
        }
        saving = true
        tvStatus?.text = "Шукаю графік…"
        val label = city.substringBefore(" (").trim() + ", " + street + ", " + house
        js("window.__va.submit()") { r ->
            if (decode(r) == "nobtn") fail("Не вдалося відправити запит. Спробуйте ще раз.")
            else { pollTries = 0; ui.postDelayed({ pollResult(label) }, 1000) }
        }
    }

    private fun fail(msg: String) {
        saving = false
        tvStatus?.text = msg
    }

    private fun pollResult(label: String) {
        if (!onAddress) return
        js("window.__va.scrape()") { r ->
            var sc: Scraped? = null
            try {
                val s = decode(r)
                if (s != null) sc = parseScraped(JSONObject(s))
            } catch (e: Exception) { }
            if (sc != null) {
                sc.addr = label
                saveAddress(sc)
            } else if (++pollTries < 45) {
                tvStatus?.text = "Шукаю графік… $pollTries с"
                ui.postDelayed({ pollResult(label) }, 1000)
            } else {
                fail("Графік не з'явився. Спробуйте ще раз або оберіть графік вручну.")
            }
        }
    }

    /** Запасний варіант: користувач сам обирає групу відключень. */
    private fun manualGroup() {
        val items = Refresher.GROUPS.map { "Група $it" }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Оберіть графік")
            .setItems(items) { _, which ->
                val g = Refresher.GROUPS[which]
                val city = fieldEt[0]?.text?.toString()?.substringBefore(" (")?.trim() ?: ""
                val street = fieldEt[1]?.text?.toString()?.trim() ?: ""
                val house = fieldEt[2]?.text?.toString()?.trim() ?: ""
                val label = listOf(city, street, house).filter { it.isNotEmpty() }.joinToString(", ").ifBlank { "Моя адреса" }
                Scheduler.prefs(this).edit().putString("address", label).putString("group", g).apply()
                tvStatus?.text = "Завантажую графік…"
                Thread {
                    val res = Refresher.refresh(this, false)
                    runOnUiThread { if (res.startsWith("Помилка")) tvStatus?.text = res else showMain() }
                }.start()
            }
            .show()
    }

    private fun copyDiag() {
        js("window.__va.diag()") { r ->
            val s = decode(r) ?: "порожньо"
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("diag", s))
            Toast.makeText(this, "Діагностику скопійовано — вставте її в чат", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseScraped(o: JSONObject): Scraped? {
        val heads = o.getJSONArray("heads")
        val rows = o.getJSONArray("rows")
        if (rows.length() == 0) return null
        val today = LocalDate.now(Scheduler.KYIV)
        val ncols = rows.getJSONObject(0).getJSONArray("v").length()
        if (ncols == 0) return null
        val dates = ArrayList<LocalDate>()
        for (i in 0 until ncols) {
            var d = today.plusDays(i.toLong())
            if (i < heads.length()) {
                val m = Regex("(\\d{1,2})\\.(\\d{1,2})").find(heads.getString(i))
                if (m != null) {
                    val day = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt()
                    var y = today.year
                    if (mo == 1 && today.monthValue == 12) y++
                    if (mo == 12 && today.monthValue == 1) y--
                    try { d = LocalDate.of(y, mo, day) } catch (e: Exception) { }
                }
            }
            dates.add(d)
        }
        val masks = HashMap<LocalDate, BooleanArray>()
        for (d in dates) masks[d] = BooleanArray(24)
        for (r in 0 until rows.length()) {
            val row = rows.getJSONObject(r)
            val hour = row.getInt("h")
            val v = row.getJSONArray("v")
            if (hour !in 0..23) continue
            for (i in 0 until minOf(ncols, v.length())) masks[dates[i]]!![hour] = v.getInt(i) == 2
        }
        val days = Days()
        for ((d, mask) in masks) {
            val list = ArrayList<IntArray>()
            var start = -1
            for (h in 0..24) {
                val on = h < 24 && mask[h]
                if (on && start < 0) start = h
                if (!on && start >= 0) { list.add(intArrayOf(start * 60, h * 60)); start = -1 }
            }
            days[d] = list
        }
        val q = if (o.isNull("queue")) null else o.getString("queue")
        return Scraped(masks, days, q, o.optString("addr", ""))
    }

    private fun saveAddress(sc: Scraped) {
        if (saving) return
        saving = true
        tvStatus?.text = "Зберігаю…"
        Thread {
            try {
                var group = sc.queue?.takeIf { it in Refresher.GROUPS }
                if (group != null) {
                    val s = Refresher.score(group, sc.masks)
                    if (s != null && s.second > 0 && s.first < s.second * 0.85) group = null
                }
                val anyOutage = sc.masks.values.any { m -> m.any { it } }
                if (group == null && anyOutage) group = Refresher.detectGroup(sc.masks)
                if (group == null && !anyOutage) {
                    runOnUiThread {
                        fail("Не вдалося автоматично визначити графік. Оберіть його вручну.")
                        manualGroup()
                    }
                    return@Thread
                }
                val ed = Scheduler.prefs(this).edit()
                ed.putString("address", sc.addr.ifBlank { "Моя адреса" })
                if (group != null) ed.putString("group", group) else ed.remove("group")
                ed.apply()
                Scheduler.update(this, sc.days)
                if (group != null) Refresher.refresh(this, false)
                Refresher.schedulePeriodic(this)
                runOnUiThread {
                    showMain()
                    val p = Scheduler.prefs(this)
                    if (!p.getBoolean("bg_asked", false)) {
                        p.edit().putBoolean("bg_asked", true).apply()
                        setupBackground()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { saving = false; Toast.makeText(this, "Не вдалося зберегти: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    companion object {
        const val URL = "https://disconnection.voe.com.ua/"

        /** Драйвер прихованої сторінки VOE (id полів і списків підказок взято з діагностики). */
        const val VA_JS = """(function(){if(window.__va)return;
window.__net=[];
try{var of=window.fetch;if(of){window.fetch=function(){var a=arguments,p=of.apply(this,a);try{p.then(function(r){r.clone().text().then(function(t){window.__net.push({u:String((a[0]&&a[0].url)||a[0]),s:r.status,b:t.slice(0,1500)});if(window.__net.length>20)window.__net.shift();}).catch(function(){});}).catch(function(){});}catch(e){}return p;};}
var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__u=u;return XO.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){try{window.__net.push({u:String(x.__u),s:x.status,b:String(x.responseText).slice(0,1500)});if(window.__net.length>20)window.__net.shift();}catch(e){}});return XS.apply(this,arguments);};}catch(e){}
var IDS=[['cityInput','citySuggest'],['streetInput','streetSuggest'],['houseInput','houseSuggest']];
function click(e){['mousedown','mouseup','click'].forEach(function(n){e.dispatchEvent(new MouseEvent(n,{bubbles:true,cancelable:true,view:window}));});}
function setv(el,v){var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(el,v);
 ['input','change'].forEach(function(n){el.dispatchEvent(new Event(n,{bubbles:true}));});
 ['keydown','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{bubbles:true,key:'a'}));});}
function items(root){var n=root;while(n.children.length===1&&n.children[0].children.length>0)n=n.children[0];
 return Array.prototype.filter.call(n.children,function(c){var t=(c.innerText||'').trim();return t.length>0&&!/не знайдено|завантаж/i.test(t);});}
function read(idx){var root=document.getElementById(IDS[idx][1]);if(!root)return [];
 Array.prototype.forEach.call(document.querySelectorAll('[data-va]'),function(x){x.removeAttribute('data-va');});
 var out=[];items(root).slice(0,10).forEach(function(e,i){e.setAttribute('data-va',String(i));out.push((e.innerText||'').trim().replace(/\s+/g,' '));});return out;}
function colorOf(e,p){var cs=getComputedStyle(e,p||null),m=(cs.backgroundColor||'').match(/[\d.]+/g);
 if(m&&(m.length<4||+m[3]>=0.5))return m;
 var g=(cs.backgroundImage||'').match(/rgba?\([^)]*\)/);if(g){m=g[0].match(/[\d.]+/g);if(m&&(m.length<4||+m[3]>=0.5))return m;}
 return null;}
function klass(m){if(!m)return 0;var r=+m[0],g=+m[1],b=+m[2];
 if(r>200&&g>50&&g<165&&b<110)return 2;if(r>220&&g>=165&&b<110)return 1;return 0;}
window.__va={
 type:function(idx,v){var el=document.getElementById(IDS[idx][0]);if(!el)return 'noinput';el.focus();setv(el,v);return 'ok';},
 read:function(idx){return JSON.stringify(read(idx));},
 pick:function(idx,i){var e=document.querySelector('[data-va="'+i+'"]');if(!e)return 'none';click(e);return 'ok';},
 submit:function(){var b=document.querySelector('button.address-submit');if(!b)return 'nobtn';click(b);return 'ok';},
 scrape:function(){try{
  var all=document.querySelectorAll('body *'),hours=[],heads=[];
  for(var i=0;i<all.length;i++){var e=all[i];if(e.children.length>0)continue;
   var t=(e.textContent||'').trim();if(!t||t.length>12)continue;
   var r=e.getBoundingClientRect();if(r.width<=0||r.height<=0)continue;
   if(/^\d{1,2}\s*[-–]\s*\d{1,2}$/.test(t))hours.push({h:parseInt(t,10),cy:r.top+r.height/2});
   else if(/^(?:[А-Яа-яІіЇїЄє]{2}\.?\s*)?\d{1,2}\.\d{1,2}$/.test(t))heads.push({t:t,cx:r.left+r.width/2,cy:r.top+r.height/2});}
  var byH={};hours.forEach(function(x){if(!(x.h in byH))byH[x.h]=x;});
  hours=Object.keys(byH).map(function(k){return byH[k];}).sort(function(a,b){return a.cy-b.cy;});
  if(hours.length<20)return null;
  var minY=hours[0].cy;heads=heads.filter(function(x){return x.cy<minY;}).sort(function(a,b){return a.cx-b.cx;});
  var hh=[];heads.forEach(function(x){if(!hh.length||Math.abs(x.cx-hh[hh.length-1].cx)>20)hh.push(x);else if(x.t.length>hh[hh.length-1].t.length)hh[hh.length-1]=x;});heads=hh;
  if(!heads.length)return null;
  var rh=(hours[hours.length-1].cy-hours[0].cy)/(hours.length-1),cs=300;
  for(var k=1;k<heads.length;k++){cs=Math.min(cs,heads[k].cx-heads[k-1].cx);}
  var grid=hours.map(function(x){var v=[];for(var k=0;k<heads.length;k++)v.push(0);return {h:x.h,v:v};});
  for(var i=0;i<all.length;i++){var e=all[i];var r=e.getBoundingClientRect();
   if(r.width<=2||r.height<=2||r.height>rh*1.6||r.width>cs*1.15)continue;
   var c=klass(colorOf(e));if(!c)c=Math.max(klass(colorOf(e,'::before')),klass(colorOf(e,'::after')));
   if(!c)continue;
   var cy=r.top+r.height/2,cx=r.left+r.width/2,bi=-1,bd=1e9,bj=-1,bx=1e9;
   for(var k=0;k<hours.length;k++){var d=Math.abs(hours[k].cy-cy);if(d<bd){bd=d;bi=k;}}
   if(bd>rh*0.6)continue;
   for(var k=0;k<heads.length;k++){var d=Math.abs(heads[k].cx-cx);if(d<bx){bx=d;bj=k;}}
   if(bx>cs*0.7)continue;
   if(c>grid[bi].v[bj])grid[bi].v[bj]=c;}
  var q=(document.body.innerText||'').match(/(?:[Чч]ерг[аиу]|[Гг]руп[аиу])[^0-9\n]{0,20}(\d)\.(\d)/);
  return JSON.stringify({heads:heads.map(function(x){return x.t;}),rows:grid,queue:q?q[1]+'.'+q[2]:null});
 }catch(e){return null;}},
 diag:function(){var o={url:location.href,ids:[],net:window.__net||[]};
  ['cityId','streetId','houseId'].forEach(function(i){var el=document.getElementById(i);o.ids.push(el?el.value:null);});
  var all=document.querySelectorAll('body *'),rt=null;
  for(var i=0;i<all.length;i++){if(all[i].children.length===0&&/Часові\s+проміжки/i.test(all[i].textContent||'')){rt=all[i];break;}}
  if(rt){var n=rt;for(var k=0;k<4&&n.parentElement;k++)n=n.parentElement;o.result=n.outerHTML.slice(0,5000);}
  o.bodyText=(document.body.innerText||'').slice(0,1500);
  return JSON.stringify(o);}
};})()"""
    }
}
