package ua.vinnitsa.power

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.time.LocalDate
import java.time.ZonedDateTime

private object Pal {
    val GRAY = 0xFF9A93BD.toInt()
    val GREEN = 0xFF4ADE80.toInt()
    val RED = 0xFFFF5C5C.toInt()
    val WHITE = Color.WHITE
}

private class Scraped(val days: Days, val queue: String?, var addr: String)

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var rain: RainView
    private lateinit var holder: FrameLayout
    private lateinit var web: WebView
    private var onAddress = false
    private var saving = false
    private var tickAction: (() -> Unit)? = null
    private val chosen = booleanArrayOf(false, false, false)
    private val fieldEt = arrayOfNulls<EditText>(3)
    private val sugBox = arrayOfNulls<LinearLayout>(3)
    private val typeRun = arrayOfNulls<Runnable>(3)
    private var suppress = false
    private var tvStatus: TextView? = null
    private var pollTries = 0
    private var pageLoadedAt = 0L
    private var reqSeq = 0
    private val pending = HashMap<String, (String) -> Unit>()
    private val selLabel = Array(3) { "" }
    private val selId = Array(3) { "" }
    private val selQ = Array(3) { "" }
    private val lastQ = Array(3) { "" }

    private val tick = object : Runnable {
        override fun run() { tickAction?.invoke(); ui.postDelayed(this, 30_000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notifier.ensure(this)
        rain = RainView(this)
        holder = FrameLayout(this)
        web = makeWeb()
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val cover = View(this)
        cover.setBackgroundColor(0xFF0A0612.toInt())
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))
        root.addView(rain, FrameLayout.LayoutParams(-1, -1))
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        Refresher.schedulePeriodic(this)
        if (Scheduler.prefs(this).getString("address", null) == null) showAddress() else showMain()
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleAll(this)
        if (!onAddress && tickAction != null) { ui.removeCallbacks(tick); ui.post(tick) }
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val has = Scheduler.prefs(this).getString("address", null) != null
        if (onAddress && has) showMain()
        else super.onBackPressed()
    }

    // ================= UI-хелперы =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.textSize = sp; tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.setColor(0xCC141022.toInt()); bg.cornerRadius = dpf(22f); bg.setStroke(dp(1), 0x33A78BFA)
        l.background = bg
        l.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        return l
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val shape = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (filled) intArrayOf(0xFF7C3AED.toInt(), 0xFFB05CF6.toInt()) else intArrayOf(0x1AFFFFFF, 0x1AFFFFFF)
        )
        shape.cornerRadius = dpf(18f)
        if (!filled) shape.setStroke(dp(1), 0x66A78BFA)
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE); mask.cornerRadius = dpf(18f)
        val t = TextView(this)
        t.text = text; t.textSize = 15f; t.setTextColor(Color.WHITE); t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(14), dp(14), dp(14))
        t.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape, mask)
        t.isClickable = true
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        return t
    }

    private fun dayTitle(d: LocalDate): String {
        val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
        return names[d.dayOfWeek.value - 1] + " %02d.%02d".format(d.dayOfMonth, d.monthValue)
    }

    // ================= Головний екран =================
    private fun showMain() {
        onAddress = false
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val p = Scheduler.prefs(this)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ico = ImageView(this)
        ico.setImageResource(R.mipmap.ic_launcher)
        head.addView(ico, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(label("VoltAlert", 24f, Pal.WHITE, true))
        titles.addView(label(p.getString("address", "") ?: "", 13f, Pal.GRAY))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(head)

        // статус
        val statusCard = card()
        val tvState = label("", 26f, Pal.WHITE, true)
        val tvSub = label("", 14f, Pal.GRAY)
        statusCard.addView(tvState); statusCard.addView(tvSub)
        col.addView(statusCard)

        // график
        val sv = ScheduleView(this)

        fun updateStatus() {
            val st = Scheduler.state(this)
            if (st == null) {
                tvState.text = "Немає даних"; tvState.setTextColor(Pal.GRAY)
                tvSub.text = "Натисніть «Оновити»"
                return
            }
            val now = System.currentTimeMillis()
            val at = st.changeAt
            if (st.off) {
                tvState.text = "Світла немає"; tvState.setTextColor(Pal.RED)
                tvSub.text = if (at != null) "Увімкнуть о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Час увімкнення невідомий"
            } else {
                tvState.text = "Світло є"; tvState.setTextColor(Pal.GREEN)
                tvSub.text = if (at != null) "Відключення о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Найближчих відключень немає"
            }
        }

        fun renderSchedule() {
            val days = Scheduler.loadDays(this)
            val today = LocalDate.now(Scheduler.KYIV)
            val tom = today.plusDays(1)
            sv.cols = listOf(
                ScheduleView.Col(dayTitle(today), "сьогодні", days[today]),
                ScheduleView.Col(dayTitle(tom), "завтра", days[tom])
            )
            val z = ZonedDateTime.now(Scheduler.KYIV)
            sv.nowMin = z.hour * 60 + z.minute
            sv.invalidate()
        }

        val tvUpdated = label(p.getString("updated", "") ?: "", 12f, Pal.GRAY)
        tvUpdated.gravity = Gravity.CENTER
        tvUpdated.setPadding(0, dp(10), 0, 0)

        // кнопки
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val bCalc = button("Розрахувати час", true) { showCalc() }
        val bRefresh = button("Оновити", false) {
            tvUpdated.text = "Оновлення…"
            refreshNow { r -> tvUpdated.text = r }
        }
        (bCalc.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bRefresh.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        row.addView(bCalc); row.addView(bRefresh)
        col.addView(row)

        // графік-картка
        val gCard = card()
        gCard.addView(label("Графік відключень", 17f, Pal.WHITE, true))
        val legend = SpannableStringBuilder("■ немає світла     ■ є світло")
        legend.setSpan(ForegroundColorSpan(0xFFFF5A36.toInt()), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        legend.setSpan(ForegroundColorSpan(0xFF3A2F5E.toInt()), 17, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tvLegend = label("", 12f, Pal.GRAY)
        tvLegend.text = legend
        tvLegend.setPadding(0, dp(4), 0, dp(10))
        gCard.addView(tvLegend)
        gCard.addView(sv, LinearLayout.LayoutParams(-1, -2))
        col.addView(gCard)

        // сповіщення
        val nCard = card()
        nCard.addView(label("Сповіщення", 17f, Pal.WHITE, true))
        notifBlock(nCard, "Про відключення", true)
        notifBlock(nCard, "Про увімкнення", false)
        val soundRow = LinearLayout(this)
        soundRow.orientation = LinearLayout.HORIZONTAL
        val bTest = button("Перевірити", false) {
            Notifier.show(this, "Перевірка", "Так звучатимуть попередження про світло")
        }
        val bSound = button("Звук", false) {
            Notifier.ensure(this)
            try {
                startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH)
                )
            } catch (e: Exception) { }
        }
        (bTest.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bSound.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        soundRow.addView(bTest); soundRow.addView(bSound)
        nCard.addView(soundRow)
        nCard.addView(button("Робота у фоні", false) { setupBackground() })
        col.addView(nCard)

        col.addView(button("Змінити адресу", false) { showAddress() })
        col.addView(tvUpdated)

        tickAction = { updateStatus(); renderSchedule() }
        tickAction?.invoke()
        ui.removeCallbacks(tick); ui.post(tick)
        if (System.currentTimeMillis() - p.getLong("upd_ts", 0L) > 15 * 60_000L) refreshNow { r -> tvUpdated.text = r }
    }

    private val leads = intArrayOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240)

    private fun notifBlock(parent: LinearLayout, title: String, off: Boolean) {
        val p = Scheduler.prefs(this)
        val kEn = if (off) "notif_off" else "notif_on"
        val kLead = if (off) "lead_off" else "lead_on"
        val enabled = p.getBoolean(kEn, true)

        val sw = Switch(this)
        sw.text = title; sw.textSize = 16f; sw.setTextColor(Color.WHITE); sw.isChecked = enabled
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFC4B5FD.toInt(), 0xFF9CA3AF.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x887C3AED.toInt(), 0x44FFFFFF))
        sw.setPadding(0, dp(12), 0, dp(4))

        val sp = Spinner(this)
        val labels = leads.map { "За " + Scheduler.leadText(it) }
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        val cur = p.getInt(kLead, 30)
        sp.setSelection(leads.indexOf(cur).let { if (it < 0) 4 else it }, false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (leads[pos] != p.getInt(kLead, 30)) {
                    p.edit().putInt(kLead, leads[pos]).apply()
                    Scheduler.scheduleAll(this@MainActivity)
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) { }
        }
        sp.isEnabled = enabled; sp.alpha = if (enabled) 1f else 0.4f
        sw.setOnCheckedChangeListener { _, on ->
            p.edit().putBoolean(kEn, on).apply()
            sp.isEnabled = on; sp.alpha = if (on) 1f else 0.4f
            Scheduler.scheduleAll(this)
        }

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.addView(label("Попередити", 14f, Pal.GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(sp, LinearLayout.LayoutParams(-2, -2))
        parent.addView(sw, LinearLayout.LayoutParams(-1, -2))
        parent.addView(line, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshNow(done: ((String) -> Unit)? = null) {
        Thread {
            val r = Refresher.refresh(this, false)
            runOnUiThread { if (!isFinishing) { done?.invoke(r); tickAction?.invoke() } }
        }.start()
    }

    private fun showCalc() {
        val days = Scheduler.loadDays(this)
        val st = Scheduler.state(this)
        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        if (st == null) {
            sb.append("Даних про графік ще немає.")
        } else {
            val at = st.changeAt
            if (st.off) {
                sb.append("Зараз світла немає.\n")
                if (at != null) sb.append("Увімкнуть о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                val later = st.laterStart
                if (later != null) sb.append("Потім відключення о ${Scheduler.whenText(later)}.\n")
            } else {
                sb.append("Зараз світло є.\n")
                if (at != null) sb.append("Відключення о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                else sb.append("Найближчих відключень немає.\n")
            }
        }
        val today = LocalDate.now(Scheduler.KYIV)
        fun total(d: LocalDate): String {
            val m = Scheduler.minutesOff(days[d]) ?: return "графік ще не опубліковано"
            return Scheduler.dur(m * 60_000L)
        }
        sb.append("\nБез світла сьогодні: ").append(total(today))
        sb.append("\nБез світла завтра: ").append(total(today.plusDays(1)))
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Розрахунок часу")
            .setMessage(sb.toString())
            .setPositiveButton("Добре", null)
            .show()
    }

    private fun setupBackground() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                return
            }
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
            Toast.makeText(this, "Усе налаштовано ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    // ================= Екран адреси (поля в застосунку, дані — з API VOE) =================
    private fun makeWeb(): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "VAB")
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                v.evaluateJavascript(VA_JS, null)
                pageLoadedAt = System.currentTimeMillis()
            }
        }
        return w
    }

    private inner class Bridge {
        @JavascriptInterface
        fun res(id: String, json: String) { ui.post { pending.remove(id)?.invoke(json) } }
    }

    private fun jq(s: String): String = JSONObject.quote(s)

    private fun decode(raw: String?): String? = try {
        val v = JSONTokener(raw ?: "null").nextValue()
        if (v is String) v else null
    } catch (e: Exception) { null }

    /** Виконує JS на прихованій сторінці VOE (спочатку гарантує наявність драйвера). */
    private fun js(code: String, cb: ((String?) -> Unit)? = null) {
        web.evaluateJavascript(VA_JS, null)
        web.evaluateJavascript(code) { cb?.invoke(it) }
    }

    /** Той самий запит підказок, що робить сторінка VOE, але напряму — без вводу в їхні поля. */
    private fun autocomplete(type: String, text: String, ref: String, cb: (List<Pair<String, String>>?) -> Unit) {
        val id = "r" + (++reqSeq)
        pending[id] = { raw ->
            var out: List<Pair<String, String>>? = null
            try {
                val o = JSONObject(raw)
                if (o.optBoolean("ok")) {
                    val arr = o.optJSONArray("items")
                    val l = ArrayList<Pair<String, String>>()
                    if (arr != null) for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        l.add(item.optString("id") to item.optString("label"))
                    }
                    out = l
                }
            } catch (e: Exception) { }
            cb(out)
        }
        js("window.__va.ac(${jq(id)},${jq(type)},${jq(text)},${jq(ref)})")
    }

    private fun showAddress() {
        onAddress = true; saving = false
        ui.removeCallbacks(tick)
        for (i in 0..2) { chosen[i] = false; typeRun[i]?.let { ui.removeCallbacks(it) } }
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val p = Scheduler.prefs(this)
        val hasAddr = p.getString("address", null) != null

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(label("Ваша адреса", 26f, Pal.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (hasAddr) {
            val close = button("Назад", false) { showMain() }
            (close.layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0; width = -2 }
            close.setPadding(dp(20), dp(8), dp(20), dp(8))
            bar.addView(close)
        }
        col.addView(bar)

        val c = card()
        fieldBlock(c, 0, "Населений пункт", "Почніть вводити назву")
        fieldBlock(c, 1, "Вулиця", "Спочатку оберіть населений пункт")
        fieldBlock(c, 2, "Будинок", "Номер будинку")
        col.addView(c)

        // збережена адреса підставляється автоматично; можна лише змінити
        for (i in 0..2) {
            val l = p.getString("a_l$i", null) ?: continue
            setField(i, l)
            chosen[i] = true
            selLabel[i] = l
            selQ[i] = p.getString("a_q$i", "") ?: ""
            selId[i] = p.getString("a_i$i", "") ?: ""
        }

        val st = label("", 14f, Pal.GRAY)
        st.setPadding(dp(4), dp(12), dp(4), 0)
        tvStatus = st
        col.addView(st)
        col.addView(button("Перевірити адресу", true) { submitAddress() })

        val man = label("Не виходить? Обрати графік вручну", 13f, 0xFFA78BFA.toInt())
        man.gravity = Gravity.CENTER
        man.setPadding(0, dp(18), 0, 0)
        man.setOnClickListener { manualGroup() }
        col.addView(man)
        val diag = label("Надіслати діагностику", 12f, Pal.GRAY)
        diag.gravity = Gravity.CENTER
        diag.setPadding(0, dp(14), 0, 0)
        diag.setOnClickListener { copyDiag() }
        col.addView(diag)

        // сторінку VOE тримаємо завантаженою у фоні (потрібна для запитів)
        if (System.currentTimeMillis() - pageLoadedAt > 10 * 60_000L) web.loadUrl(URL)
        else js("window.__search=null;window.__flow='';")
    }

    private fun fieldBlock(parent: LinearLayout, idx: Int, title: String, hint: String) {
        val t = label(title, 13f, Pal.GRAY)
        t.setPadding(dp(2), if (idx == 0) 0 else dp(14), 0, dp(6))
        parent.addView(t)

        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(0x66FFFFFF)
        et.setTextColor(Color.WHITE)
        et.textSize = 16f
        et.setSingleLine(true)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(0xFF1A1330.toInt()); bg.cornerRadius = dpf(14f); bg.setStroke(dp(1), 0x44A78BFA)
        et.background = bg
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun afterTextChanged(s: Editable?) { if (!suppress) onType(idx, s?.toString() ?: "") }
        })
        parent.addView(et, LinearLayout.LayoutParams(-1, -2))

        val sug = LinearLayout(this)
        sug.orientation = LinearLayout.VERTICAL
        sug.visibility = View.GONE
        val sbg = GradientDrawable()
        sbg.setColor(0xFF211A3A.toInt()); sbg.cornerRadius = dpf(14f)
        sug.background = sbg
        parent.addView(sug, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        fieldEt[idx] = et; sugBox[idx] = sug
    }

    private fun setField(idx: Int, text: String) {
        suppress = true
        fieldEt[idx]?.setText(text)
        fieldEt[idx]?.setSelection(text.length)
        suppress = false
    }

    private fun onType(idx: Int, text: String) {
        chosen[idx] = false
        for (j in idx + 1..2) {
            if (fieldEt[j]?.text?.isNotEmpty() == true) setField(j, "")
            chosen[j] = false
            sugBox[j]?.visibility = View.GONE
        }
        sugBox[idx]?.visibility = View.GONE
        typeRun[idx]?.let { ui.removeCallbacks(it) }
        val need = if (idx == 2) 1 else 2
        if (text.trim().length < need) return
        if (idx > 0 && !chosen[idx - 1]) {
            tvStatus?.text = "Спершу оберіть попередній пункт зі списку підказок"
            return
        }
        tvStatus?.text = ""
        val r = Runnable { suggest(idx, text.trim(), 0) }
        typeRun[idx] = r
        ui.postDelayed(r, 120)
    }

    private fun suggest(idx: Int, text: String, attempt: Int) {
        if (!onAddress || fieldEt[idx]?.text?.toString()?.trim() != text) return
        lastQ[idx] = text
        val ref = if (idx == 0) "" else selId[idx - 1]
        autocomplete(arrayOf("city", "street", "house")[idx], text, ref) { items ->
            if (!onAddress || fieldEt[idx]?.text?.toString()?.trim() != text) return@autocomplete
            if (items == null) {
                if (attempt < 6) {
                    tvStatus?.text = "З'єднання з сервісом…"
                    ui.postDelayed({ suggest(idx, text, attempt + 1) }, 1200)
                } else tvStatus?.text = "Сервіс VOE недоступний. Спробуйте пізніше або оберіть графік вручну."
            } else {
                tvStatus?.text = ""
                showSuggestions(idx, items)
            }
        }
    }

    private fun showSuggestions(idx: Int, items: List<Pair<String, String>>) {
        val box = sugBox[idx] ?: return
        box.removeAllViews()
        if (items.isEmpty()) {
            tvStatus?.text = "Нічого не знайдено — перевірте назву"
            box.visibility = View.GONE
            return
        }
        for ((id, text) in items) {
            val row = TextView(this)
            row.text = text; row.textSize = 15f; row.setTextColor(Color.WHITE)
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            val mask = GradientDrawable()
            mask.setColor(Color.WHITE); mask.cornerRadius = dpf(14f)
            row.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), null, mask)
            row.isClickable = true
            row.setOnClickListener { pick(idx, id, text) }
            box.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        box.visibility = View.VISIBLE
    }

    private fun pick(idx: Int, id: String, text: String) {
        selId[idx] = id; selLabel[idx] = text; selQ[idx] = lastQ[idx]
        setField(idx, text)
        chosen[idx] = true
        sugBox[idx]?.visibility = View.GONE
        tvStatus?.text = ""
        if (idx < 2) fieldEt[idx + 1]?.requestFocus()
    }

    private fun submitAddress() {
        if (saving) return
        if (!chosen.all { it }) {
            Toast.makeText(this, "Оберіть населений пункт, вулицю й будинок зі списку підказок", Toast.LENGTH_LONG).show()
            return
        }
        saving = true
        tvStatus?.text = "Шукаю графік…"
        val label = selLabel[0].substringBefore(" (").trim() + ", " + selLabel[1] + ", " + selLabel[2]
        js("window.__va.flow(${jq(selLabel[0])},${jq(selQ[0])},${jq(selLabel[1])},${jq(selQ[1])},${jq(selLabel[2])},${jq(selQ[2])})")
        pollTries = 0
        ui.postDelayed({ pollResult(label) }, 500)
    }

    private fun fail(msg: String) {
        saving = false
        tvStatus?.text = msg
    }

    private fun pollResult(label: String) {
        if (!onAddress) return
        js("window.__va.poll()") { r ->
            var flow = ""
            var body: String? = null
            try {
                val s = decode(r)
                if (s != null) {
                    val o = JSONObject(s)
                    flow = o.optString("f")
                    if (!o.isNull("s")) body = o.getString("s")
                }
            } catch (e: Exception) { }
            if (flow.startsWith("fail")) {
                fail("Не вдалося підтвердити адресу на сайті. Спробуйте ще раз.")
            } else if (body != null) {
                val problem = searchProblem(body)
                if (problem != null) fail(problem)
                else {
                    val sc = parseSearch(body, label)
                    if (sc != null) saveAddress(sc) else fail("Не вдалося розібрати графік. Оберіть його вручну.")
                }
            } else if (++pollTries < 110) {
                if (pollTries % 3 == 0) tvStatus?.text = "Шукаю графік… ${pollTries * 4 / 10} с"
                ui.postDelayed({ pollResult(label) }, 400)
            } else {
                fail("Графік не з'явився. Спробуйте ще раз або оберіть графік вручну.")
            }
        }
    }

    private fun searchProblem(text: String): String? {
        return try {
            val o = JSONObject(text)
            if (!o.optBoolean("ok")) "Сайт повернув помилку. Спробуйте ще раз."
            else {
                val t = o.optJSONArray("tables")
                if (t == null || t.length() == 0) "Для цієї адреси графік не знайдено." else null
            }
        } catch (e: Exception) { "Не вдалося прочитати відповідь сайту." }
    }

    /** Відповідь api/search.php: tables[0].listnum — група, rows[] — дні, cells[].segments — відсотки години. */
    private fun parseSearch(text: String, label: String): Scraped? {
        return try {
            val t = JSONObject(text).getJSONArray("tables").getJSONObject(0)
            val rows = t.getJSONArray("rows")
            val days = Days()
            for (r in 0 until rows.length()) {
                val row = rows.getJSONObject(r)
                val date = try { LocalDate.parse(row.getString("date")) } catch (e: Exception) { continue }
                val cells = row.getJSONArray("cells")
                val raw = ArrayList<IntArray>()
                for (c in 0 until cells.length()) {
                    val cell = cells.getJSONObject(c)
                    val hour = cell.optString("hour").substringBefore("-").trim().toIntOrNull() ?: continue
                    val segs = cell.optJSONArray("segments") ?: continue
                    for (k in 0 until segs.length()) {
                        val sg = segs.getJSONObject(k)
                        if (sg.optInt("level", 0) < 2) continue
                        val st = hour * 60 + Math.round(sg.optDouble("start", 0.0) * 0.6).toInt()
                        val en = st + Math.round(sg.optDouble("size", 100.0) * 0.6).toInt()
                        raw.add(intArrayOf(st, minOf(en, 1440)))
                    }
                }
                raw.sortBy { it[0] }
                val merged = ArrayList<IntArray>()
                for (iv in raw) {
                    val last = merged.lastOrNull()
                    if (last != null && iv[0] <= last[1]) last[1] = maxOf(last[1], iv[1]) else merged.add(intArrayOf(iv[0], iv[1]))
                }
                days[date] = merged
            }
            if (days.isEmpty()) null else Scraped(days, t.optString("listnum", "").ifBlank { null }, label)
        } catch (e: Exception) { null }
    }

    /** Запасний варіант: користувач сам обирає групу відключень. */
    private fun manualGroup() {
        val items = Refresher.GROUPS.map { "Група $it" }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Оберіть графік")
            .setItems(items) { _, which ->
                val g = Refresher.GROUPS[which]
                val city = fieldEt[0]?.text?.toString()?.substringBefore(" (")?.trim() ?: ""
                val street = fieldEt[1]?.text?.toString()?.trim() ?: ""
                val house = fieldEt[2]?.text?.toString()?.trim() ?: ""
                val label = listOf(city, street, house).filter { it.isNotEmpty() }.joinToString(", ").ifBlank { "Моя адреса" }
                Scheduler.prefs(this).edit().putString("address", label).putString("group", g).apply()
                tvStatus?.text = "Завантажую графік…"
                Thread {
                    val res = Refresher.refresh(this, false)
                    runOnUiThread { if (res.startsWith("Помилка")) tvStatus?.text = res else showMain() }
                }.start()
            }
            .show()
    }

    private fun copyDiag() {
        js("window.__va.diag()") { r ->
            val s = decode(r) ?: "порожньо"
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("diag", s))
            Toast.makeText(this, "Діагностику скопійовано — вставте її в чат", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveAddress(sc: Scraped) {
        tvStatus?.text = "Зберігаю…"
        Thread {
            try {
                val ed = Scheduler.prefs(this).edit()
                ed.putString("address", sc.addr.ifBlank { "Моя адреса" })
                for (i in 0..2) {
                    ed.putString("a_l$i", selLabel[i]); ed.putString("a_q$i", selQ[i]); ed.putString("a_i$i", selId[i])
                }
                if (sc.queue != null) ed.putString("group", sc.queue) else ed.remove("group")
                ed.putString("updated", "Оновлено о " + java.time.LocalTime.now(Scheduler.KYIV).toString().take(5))
                ed.putLong("upd_ts", System.currentTimeMillis())
                ed.apply()
                Scheduler.update(this, sc.days)
                Refresher.schedulePeriodic(this)
                runOnUiThread {
                    showMain()
                    val p = Scheduler.prefs(this)
                    if (!p.getBoolean("bg_asked", false)) {
                        p.edit().putBoolean("bg_asked", true).apply()
                        setupBackground()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { fail("Не вдалося зберегти: ${e.message}") }
            }
        }.start()
    }

    companion object {
        const val URL = "https://disconnection.voe.com.ua/"

        /** Драйвер прихованої сторінки VOE: запити підказок, вибір адреси, відправка форми, перехоплення відповіді. */
        const val VA_JS = """(function(){if(window.__va)return;
window.__net=[];window.__search=null;window.__flow='';
function rec(u,s,t){try{window.__net.push({u:u,s:s,b:String(t).slice(0,800)});if(window.__net.length>20)window.__net.shift();if(u.indexOf('search.php')>=0)window.__search=String(t);}catch(e){}}
try{var of=window.fetch;if(of){window.fetch=function(){var a=arguments,p=of.apply(this,a);try{var u=String((a[0]&&a[0].url)||a[0]);p.then(function(r){r.clone().text().then(function(t){rec(u,r.status,t);}).catch(function(){});}).catch(function(){});}catch(e){}return p;};}
var XO=XMLHttpRequest.prototype.open,XS=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__u=String(u);return XO.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){rec(x.__u,x.status,x.responseText);});return XS.apply(this,arguments);};}catch(e){}
var IDS=[['cityInput','citySuggest'],['streetInput','streetSuggest'],['houseInput','houseSuggest']];
function click(e){['mousedown','mouseup','click'].forEach(function(n){e.dispatchEvent(new MouseEvent(n,{bubbles:true,cancelable:true,view:window}));});}
function setv(el,v){var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(el,v);
 ['input','change'].forEach(function(n){el.dispatchEvent(new Event(n,{bubbles:true}));});
 ['keydown','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{bubbles:true,key:'a'}));});}
function items(root){if(!root)return [];var n=root;while(n.children.length===1&&n.children[0].children.length>0)n=n.children[0];
 return Array.prototype.filter.call(n.children,function(c){return (c.innerText||'').trim().length>0;});}
function step(idx,label,q,cb){
 var el=document.getElementById(IDS[idx][0]);if(!el){cb(false);return;}
 el.focus();setv(el,q);var n=0;
 var iv=setInterval(function(){
  var its=items(document.getElementById(IDS[idx][1]));
  for(var i=0;i<its.length;i++){var t=(its[i].innerText||'').trim().replace(/\s+/g,' ');
   if(t===label||t.indexOf(label)>=0){clearInterval(iv);click(its[i]);setTimeout(function(){cb(true);},200);return;}}
  if(++n>60){clearInterval(iv);cb(false);}
 },120);}
window.__va={
 ac:function(id,type,q,ref){
  try{fetch('api/autocomplete.php?type='+type+'&q='+encodeURIComponent(q)+'&ref='+encodeURIComponent(ref),{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}})
   .then(function(r){return r.text();}).then(function(t){window.VAB.res(id,t);}).catch(function(){window.VAB.res(id,'');});
  }catch(e){window.VAB.res(id,'');}
  return 'ok';},
 flow:function(cl,cq,sl,sq,hl,hq){window.__flow='run';window.__search=null;
  step(0,cl,cq,function(a){if(!a){window.__flow='fail:city';return;}
   step(1,sl,sq,function(b){if(!b){window.__flow='fail:street';return;}
    step(2,hl,hq,function(c){if(!c){window.__flow='fail:house';return;}
     var btn=document.querySelector('button.address-submit');if(!btn){window.__flow='fail:btn';return;}
     click(btn);window.__flow='sent';});});});});
  return 'ok';},
 poll:function(){return JSON.stringify({f:window.__flow||'',s:window.__search||null});},
 diag:function(){var o={url:location.href,flow:window.__flow||'',net:window.__net||[],search:(window.__search||'').slice(0,3000)};
  ['cityId','streetId','houseId'].forEach(function(i){var el=document.getElementById(i);o[i]=el?el.value:null;});
  var s=document.getElementById('citySuggest');o.citySuggest=s?s.outerHTML.slice(0,1500):null;
  return JSON.stringify(o);}
};})()"""
    }
}
