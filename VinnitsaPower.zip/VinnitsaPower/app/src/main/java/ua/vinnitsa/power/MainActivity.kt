package ua.vinnitsa.power

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.time.LocalDate
import java.time.ZonedDateTime

private object Pal {
    val GRAY = 0xFF9A93BD.toInt()
    val GREEN = 0xFF4ADE80.toInt()
    val RED = 0xFFFF5C5C.toInt()
    val WHITE = Color.WHITE
}

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var rain: RainView
    private lateinit var holder: FrameLayout
    private var onAddress = false
    private var tickAction: (() -> Unit)? = null
    private var tvStatus: TextView? = null

    private val tick = object : Runnable {
        override fun run() { tickAction?.invoke(); ui.postDelayed(this, 30_000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notifier.ensure(this)
        rain = RainView(this)
        holder = FrameLayout(this)
        val root = FrameLayout(this)
        val cover = View(this)
        cover.setBackgroundColor(0xFF0A0612.toInt())
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))
        root.addView(rain, FrameLayout.LayoutParams(-1, -1))
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        Refresher.schedulePeriodic(this)
        if (Scheduler.prefs(this).getString("address", null) == null) showAddress() else showMain()
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleAll(this)
        if (!onAddress && tickAction != null) { ui.removeCallbacks(tick); ui.post(tick) }
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val has = Scheduler.prefs(this).getString("address", null) != null
        if (onAddress && has) showMain()
        else super.onBackPressed()
    }

    // ================= UI-хелперы =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.textSize = sp; tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.setColor(0xCC141022.toInt()); bg.cornerRadius = dpf(22f); bg.setStroke(dp(1), 0x33A78BFA)
        l.background = bg
        l.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        return l
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val shape = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (filled) intArrayOf(0xFF7C3AED.toInt(), 0xFFB05CF6.toInt()) else intArrayOf(0x1AFFFFFF, 0x1AFFFFFF)
        )
        shape.cornerRadius = dpf(18f)
        if (!filled) shape.setStroke(dp(1), 0x66A78BFA)
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE); mask.cornerRadius = dpf(18f)
        val t = TextView(this)
        t.text = text; t.textSize = 15f; t.setTextColor(Color.WHITE); t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(14), dp(14), dp(14))
        t.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape, mask)
        t.isClickable = true
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        return t
    }

    private fun dayTitle(d: LocalDate): String {
        val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
        return names[d.dayOfWeek.value - 1] + " %02d.%02d".format(d.dayOfMonth, d.monthValue)
    }

    // ================= Головний екран =================
    private fun showMain() {
        onAddress = false
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val p = Scheduler.prefs(this)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ico = ImageView(this)
        ico.setImageResource(R.mipmap.ic_launcher)
        head.addView(ico, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(label("VoltAlert", 24f, Pal.WHITE, true))
        titles.addView(label(p.getString("address", "") ?: "", 13f, Pal.GRAY))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(head)

        // статус
        val statusCard = card()
        val tvState = label("", 26f, Pal.WHITE, true)
        val tvSub = label("", 14f, Pal.GRAY)
        statusCard.addView(tvState); statusCard.addView(tvSub)
        col.addView(statusCard)

        // график
        val sv = ScheduleView(this)

        fun updateStatus() {
            val st = Scheduler.state(this)
            if (st == null) {
                tvState.text = "Немає даних"; tvState.setTextColor(Pal.GRAY)
                tvSub.text = "Натисніть «Оновити»"
                return
            }
            val now = System.currentTimeMillis()
            val at = st.changeAt
            if (st.off) {
                tvState.text = "Світла немає"; tvState.setTextColor(Pal.RED)
                tvSub.text = if (at != null) "Увімкнуть о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Час увімкнення невідомий"
            } else {
                tvState.text = "Світло є"; tvState.setTextColor(Pal.GREEN)
                tvSub.text = if (at != null) "Відключення о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Найближчих відключень немає"
            }
        }

        fun renderSchedule() {
            val days = Scheduler.loadDays(this)
            val today = LocalDate.now(Scheduler.KYIV)
            val tom = today.plusDays(1)
            sv.cols = listOf(
                ScheduleView.Col(dayTitle(today), "сьогодні", days[today]),
                ScheduleView.Col(dayTitle(tom), "завтра", days[tom])
            )
            val z = ZonedDateTime.now(Scheduler.KYIV)
            sv.nowMin = z.hour * 60 + z.minute
            sv.invalidate()
        }

        val tvUpdated = label(p.getString("updated", "") ?: "", 12f, Pal.GRAY)
        tvUpdated.gravity = Gravity.CENTER
        tvUpdated.setPadding(0, dp(10), 0, 0)

        // кнопки
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val bCalc = button("Розрахувати час", true) { showCalc() }
        val bRefresh = button("Оновити", false) {
            tvUpdated.text = "Оновлення…"
            refreshNow { r -> tvUpdated.text = r }
        }
        (bCalc.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bRefresh.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        row.addView(bCalc); row.addView(bRefresh)
        col.addView(row)

        // графік-картка
        val gCard = card()
        gCard.addView(label("Графік відключень", 17f, Pal.WHITE, true))
        val legend = SpannableStringBuilder("■ немає світла     ■ є світло")
        legend.setSpan(ForegroundColorSpan(0xFFFF5A36.toInt()), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        legend.setSpan(ForegroundColorSpan(0xFF3A2F5E.toInt()), 17, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tvLegend = label("", 12f, Pal.GRAY)
        tvLegend.text = legend
        tvLegend.setPadding(0, dp(4), 0, dp(10))
        gCard.addView(tvLegend)
        gCard.addView(sv, LinearLayout.LayoutParams(-1, -2))
        col.addView(gCard)

        // сповіщення
        val nCard = card()
        nCard.addView(label("Сповіщення", 17f, Pal.WHITE, true))
        notifBlock(nCard, "Про відключення", true)
        notifBlock(nCard, "Про увімкнення", false)
        val soundRow = LinearLayout(this)
        soundRow.orientation = LinearLayout.HORIZONTAL
        val bTest = button("Перевірити", false) {
            Notifier.show(this, "Перевірка", "Так звучатимуть попередження про світло")
            Notifier.problem(this)?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        }
        val bSound = button("Звук", false) {
            Notifier.ensure(this)
            try {
                startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH)
                )
            } catch (e: Exception) { }
        }
        (bTest.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bSound.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        soundRow.addView(bTest); soundRow.addView(bSound)
        nCard.addView(soundRow)
        nCard.addView(button("Робота у фоні", false) { setupBackground() })
        col.addView(nCard)

        col.addView(button("Змінити адресу", false) { showAddress() })
        col.addView(tvUpdated)

        tickAction = { updateStatus(); renderSchedule() }
        tickAction?.invoke()
        ui.removeCallbacks(tick); ui.post(tick)
        if (System.currentTimeMillis() - p.getLong("upd_ts", 0L) > 15 * 60_000L) refreshNow { r -> tvUpdated.text = r }
    }

    private val leads = intArrayOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240)

    private fun notifBlock(parent: LinearLayout, title: String, off: Boolean) {
        val p = Scheduler.prefs(this)
        val kEn = if (off) "notif_off" else "notif_on"
        val kLead = if (off) "lead_off" else "lead_on"
        val enabled = p.getBoolean(kEn, true)

        val sw = Switch(this)
        sw.text = title; sw.textSize = 16f; sw.setTextColor(Color.WHITE); sw.isChecked = enabled
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFC4B5FD.toInt(), 0xFF9CA3AF.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x887C3AED.toInt(), 0x44FFFFFF))
        sw.setPadding(0, dp(12), 0, dp(4))

        val sp = Spinner(this)
        val labels = leads.map { "За " + Scheduler.leadText(it) }
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        val cur = p.getInt(kLead, 30)
        sp.setSelection(leads.indexOf(cur).let { if (it < 0) 4 else it }, false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (leads[pos] != p.getInt(kLead, 30)) {
                    p.edit().putInt(kLead, leads[pos]).apply()
                    Scheduler.scheduleAll(this@MainActivity)
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) { }
        }
        sp.isEnabled = enabled; sp.alpha = if (enabled) 1f else 0.4f
        sw.setOnCheckedChangeListener { _, on ->
            p.edit().putBoolean(kEn, on).apply()
            sp.isEnabled = on; sp.alpha = if (on) 1f else 0.4f
            Scheduler.scheduleAll(this)
        }

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.addView(label("Попередити", 14f, Pal.GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(sp, LinearLayout.LayoutParams(-2, -2))
        parent.addView(sw, LinearLayout.LayoutParams(-1, -2))
        parent.addView(line, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshNow(done: ((String) -> Unit)? = null) {
        Thread {
            val r = Refresher.refresh(this, true)
            runOnUiThread { if (!isFinishing) { done?.invoke(r); tickAction?.invoke() } }
        }.start()
    }

    private fun showCalc() {
        val days = Scheduler.loadDays(this)
        val st = Scheduler.state(this)
        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        if (st == null) {
            sb.append("Даних про графік ще немає.")
        } else {
            val at = st.changeAt
            if (st.off) {
                sb.append("Зараз світла немає.\n")
                if (at != null) sb.append("Увімкнуть о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                val later = st.laterStart
                if (later != null) sb.append("Потім відключення о ${Scheduler.whenText(later)}.\n")
            } else {
                sb.append("Зараз світло є.\n")
                if (at != null) sb.append("Відключення о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                else sb.append("Найближчих відключень немає.\n")
            }
        }
        val today = LocalDate.now(Scheduler.KYIV)
        fun total(d: LocalDate): String {
            val m = Scheduler.minutesOff(days[d]) ?: return "графік ще не опубліковано"
            return Scheduler.dur(m * 60_000L)
        }
        sb.append("\nБез світла сьогодні: ").append(total(today))
        sb.append("\nБез світла завтра: ").append(total(today.plusDays(1)))
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Розрахунок часу")
            .setMessage(sb.toString())
            .setPositiveButton("Добре", null)
            .show()
    }

    private fun setupBackground() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                return
            }
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
            Toast.makeText(this, "Усе налаштовано ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    // ================= Екран адреси (локальна база Вінниці) =================
    private fun input(hint: String): EditText {
        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(0x66FFFFFF); et.setTextColor(Color.WHITE); et.textSize = 16f
        et.setSingleLine(true)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(0xFF1A1330.toInt()); bg.cornerRadius = dpf(14f); bg.setStroke(dp(1), 0x44A78BFA)
        et.background = bg
        return et
    }

    private fun sugBox(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.visibility = View.GONE
        val bg = GradientDrawable()
        bg.setColor(0xFF211A3A.toInt()); bg.cornerRadius = dpf(14f)
        box.background = bg
        return box
    }

    private fun sugRow(text: String, color: Int, onClick: () -> Unit): TextView {
        val row = TextView(this)
        row.text = text
        row.textSize = 15f
        row.setTextColor(color)
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE); mask.cornerRadius = dpf(14f)
        row.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), null, mask)
        row.isClickable = true
        row.setOnClickListener { onClick() }
        return row
    }

    private fun showAddress() {
        onAddress = true
        ui.removeCallbacks(tick)
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val prefs = Scheduler.prefs(this)
        val hasAddr = prefs.getString("address", null) != null
        val savedCity = prefs.getString("city_sel", "") ?: ""

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(label("Ваша адреса", 26f, Pal.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (hasAddr) {
            val close = button("Назад", false) { showMain() }
            (close.layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0; width = -2 }
            close.setPadding(dp(20), dp(8), dp(20), dp(8))
            bar.addView(close)
        }
        col.addView(bar)

        val c = card()
        val cityEt = input("Населений пункт")
        val cityBox = sugBox()
        val street = input("Вулиця")
        val streetBox = sugBox()
        val house = input("Номер будинку")
        val box = sugBox()
        var silent = false

        fun fill(et: EditText, text: String) {
            silent = true; et.setText(text); et.setSelection(text.length); silent = false
        }
        fun rows(target: LinearLayout, items: List<TextView>) {
            target.removeAllViews()
            for (r in items) target.addView(r, LinearLayout.LayoutParams(-1, -2))
            target.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        }

        fun refresh() {
            val ct = cityEt.text.toString().trim()
            val city = AddressDb.cities(this).firstOrNull { it.equals(ct, true) }
            if (city == null) {
                rows(cityBox, AddressDb.citySuggest(this, ct).map { name ->
                    sugRow(name, Color.WHITE) {
                        fill(cityEt, name)
                        prefs.edit().putString("city_sel", name).apply()
                        street.setText(""); house.setText("")
                        street.requestFocus()
                    }
                })
            } else {
                cityBox.visibility = View.GONE
                prefs.edit().putString("city_sel", city).apply()
            }
            val hasS = city != null && AddressDb.hasStreets(this, city)
            street.visibility = if (hasS) View.VISIBLE else View.GONE
            house.visibility = if (hasS) View.VISIBLE else View.GONE
            val st = street.text.toString(); val hs = house.text.toString()

            // підказки вулиць
            val sug = if (hasS && city != null && hs.isBlank()) AddressDb.streetSuggest(this, city, st) else emptyList()
            if (sug.isNotEmpty() && sug.none { it.equals(st.trim(), true) }) {
                rows(streetBox, sug.map { name ->
                    sugRow(name, Color.WHITE) { fill(street, name); house.requestFocus() }
                })
            } else streetBox.visibility = View.GONE

            // результат
            val hits = if (city == null) emptyList() else AddressDb.search(this, city, st, hs)
            rows(box, hits.map { h ->
                sugRow(h.label + "  ·  черга " + h.queue, if (h.exact) Color.WHITE else Pal.GRAY) {
                    val clean = h.label.substringBefore(" (")
                    applyGroup(h.queue, if (hasS) "$city, $clean" else clean)
                }
            })
            tvStatus?.text = when {
                city == null || !hasS -> ""
                st.trim().length >= 2 && hs.isBlank() && sug.isEmpty() -> "Вкажіть номер будинку"
                st.trim().length >= 3 && hs.isNotBlank() && hits.isEmpty() -> "Цієї адреси немає в переліку — оберіть чергу вручну"
                else -> ""
            }
        }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c2: Int) { }
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c2: Int) { }
            override fun afterTextChanged(s: Editable?) { if (!silent) refresh() }
        }
        cityEt.addTextChangedListener(watcher)
        street.addTextChangedListener(watcher)
        house.addTextChangedListener(watcher)

        c.addView(cityEt, LinearLayout.LayoutParams(-1, -2))
        c.addView(cityBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        c.addView(street, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        c.addView(streetBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        c.addView(house, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        c.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        col.addView(c)

        val stv = label("", 14f, Pal.GRAY)
        stv.setPadding(dp(4), dp(12), dp(4), 0)
        tvStatus = stv
        col.addView(stv)
        col.addView(button("Обрати чергу вручну", false) { manualGroup() })

        if (savedCity.isNotEmpty()) fill(cityEt, savedCity)
        refresh()
    }

    private fun applyGroup(g: String, addr: String) {
        val ed = Scheduler.prefs(this).edit().putString("address", addr).putString("group", g)
        for (i in 0..2) { ed.remove("a_l$i"); ed.remove("a_q$i"); ed.remove("a_i$i") }
        ed.apply()
        tvStatus?.text = "Завантажую графік…"
        Thread {
            val res = Refresher.refresh(this, false)
            runOnUiThread { if (res.startsWith("Помилка")) tvStatus?.text = res else showMain() }
        }.start()
    }

    private fun manualGroup() {
        val items = Refresher.GROUPS.map { "Черга $it" }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Оберіть чергу")
            .setItems(items) { _, which -> applyGroup(Refresher.GROUPS[which], "Черга " + Refresher.GROUPS[which]) }
            .show()
    }
}
