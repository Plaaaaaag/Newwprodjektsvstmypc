package ua.vinnitsa.power

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.time.LocalDate
import java.time.ZonedDateTime

private object Pal {
    val GRAY = 0xFF9A93BD.toInt()
    val GREEN = 0xFF4ADE80.toInt()
    val RED = 0xFFFF5C5C.toInt()
    val WHITE = Color.WHITE
}

private class Scraped(val masks: Map<LocalDate, BooleanArray>, val days: Days, val queue: String?, var addr: String)

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var rain: RainView
    private lateinit var holder: FrameLayout
    private lateinit var web: WebView
    private var onAddress = false
    private var saving = false
    private var tickAction: (() -> Unit)? = null
    private val chosen = booleanArrayOf(false, false, false)
    private val fieldEt = arrayOfNulls<EditText>(3)
    private val sugBox = arrayOfNulls<LinearLayout>(3)
    private val typeRun = arrayOfNulls<Runnable>(3)
    private var suppress = false
    private var tvStatus: TextView? = null
    private var pollTries = 0

    private val tick = object : Runnable {
        override fun run() { tickAction?.invoke(); ui.postDelayed(this, 30_000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Notifier.ensure(this)
        rain = RainView(this)
        holder = FrameLayout(this)
        web = makeWeb()
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val cover = View(this)
        cover.setBackgroundColor(0xFF0A0612.toInt())
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))
        root.addView(rain, FrameLayout.LayoutParams(-1, -1))
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        Refresher.schedulePeriodic(this)
        if (Scheduler.prefs(this).getString("address", null) == null) showAddress() else showMain()
    }

    override fun onResume() {
        super.onResume()
        Scheduler.scheduleAll(this)
        if (!onAddress && tickAction != null) { ui.removeCallbacks(tick); ui.post(tick) }
    }

    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val has = Scheduler.prefs(this).getString("address", null) != null
        if (onAddress && has) showMain()
        else super.onBackPressed()
    }

    // ================= UI-хелперы =================
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = v * resources.displayMetrics.density

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.textSize = sp; tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(16), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.setColor(0xCC141022.toInt()); bg.cornerRadius = dpf(22f); bg.setStroke(dp(1), 0x33A78BFA)
        l.background = bg
        l.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        return l
    }

    private fun button(text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val shape = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (filled) intArrayOf(0xFF7C3AED.toInt(), 0xFFB05CF6.toInt()) else intArrayOf(0x1AFFFFFF, 0x1AFFFFFF)
        )
        shape.cornerRadius = dpf(18f)
        if (!filled) shape.setStroke(dp(1), 0x66A78BFA)
        val mask = GradientDrawable()
        mask.setColor(Color.WHITE); mask.cornerRadius = dpf(18f)
        val t = TextView(this)
        t.text = text; t.textSize = 15f; t.setTextColor(Color.WHITE); t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(14), dp(14), dp(14))
        t.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), shape, mask)
        t.isClickable = true
        t.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        return t
    }

    private fun dayTitle(d: LocalDate): String {
        val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд")
        return names[d.dayOfWeek.value - 1] + " %02d.%02d".format(d.dayOfMonth, d.monthValue)
    }

    // ================= Головний екран =================
    private fun showMain() {
        onAddress = false
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val p = Scheduler.prefs(this)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ico = ImageView(this)
        ico.setImageResource(R.mipmap.ic_launcher)
        head.addView(ico, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(label("VoltAlert", 24f, Pal.WHITE, true))
        titles.addView(label(p.getString("address", "") ?: "", 13f, Pal.GRAY))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(head)

        // статус
        val statusCard = card()
        val tvState = label("", 26f, Pal.WHITE, true)
        val tvSub = label("", 14f, Pal.GRAY)
        statusCard.addView(tvState); statusCard.addView(tvSub)
        col.addView(statusCard)

        // график
        val sv = ScheduleView(this)

        fun updateStatus() {
            val st = Scheduler.state(this)
            if (st == null) {
                tvState.text = "Немає даних"; tvState.setTextColor(Pal.GRAY)
                tvSub.text = "Натисніть «Оновити»"
                return
            }
            val now = System.currentTimeMillis()
            val at = st.changeAt
            if (st.off) {
                tvState.text = "Світла немає"; tvState.setTextColor(Pal.RED)
                tvSub.text = if (at != null) "Увімкнуть о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Час увімкнення невідомий"
            } else {
                tvState.text = "Світло є"; tvState.setTextColor(Pal.GREEN)
                tvSub.text = if (at != null) "Відключення о ${Scheduler.whenText(at)} · через ${Scheduler.dur(at - now)}" else "Найближчих відключень немає"
            }
        }

        fun renderSchedule() {
            val days = Scheduler.loadDays(this)
            val today = LocalDate.now(Scheduler.KYIV)
            val tom = today.plusDays(1)
            sv.cols = listOf(
                ScheduleView.Col(dayTitle(today), "сьогодні", days[today]),
                ScheduleView.Col(dayTitle(tom), "завтра", days[tom])
            )
            val z = ZonedDateTime.now(Scheduler.KYIV)
            sv.nowMin = z.hour * 60 + z.minute
            sv.invalidate()
        }

        val tvUpdated = label(p.getString("updated", "") ?: "", 12f, Pal.GRAY)
        tvUpdated.gravity = Gravity.CENTER
        tvUpdated.setPadding(0, dp(10), 0, 0)

        // кнопки
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val bCalc = button("Розрахувати час", true) { showCalc() }
        val bRefresh = button("Оновити", false) {
            tvUpdated.text = "Оновлення…"
            refreshNow { r -> tvUpdated.text = r }
        }
        (bCalc.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bRefresh.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        row.addView(bCalc); row.addView(bRefresh)
        col.addView(row)

        // графік-картка
        val gCard = card()
        gCard.addView(label("Графік відключень", 17f, Pal.WHITE, true))
        val legend = SpannableStringBuilder("■ немає світла     ■ є світло")
        legend.setSpan(ForegroundColorSpan(0xFFFF5A36.toInt()), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        legend.setSpan(ForegroundColorSpan(0xFF3A2F5E.toInt()), 17, 18, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tvLegend = label("", 12f, Pal.GRAY)
        tvLegend.text = legend
        tvLegend.setPadding(0, dp(4), 0, dp(10))
        gCard.addView(tvLegend)
        gCard.addView(sv, LinearLayout.LayoutParams(-1, -2))
        col.addView(gCard)

        // сповіщення
        val nCard = card()
        nCard.addView(label("Сповіщення", 17f, Pal.WHITE, true))
        notifBlock(nCard, "Про відключення", true)
        notifBlock(nCard, "Про увімкнення", false)
        val soundRow = LinearLayout(this)
        soundRow.orientation = LinearLayout.HORIZONTAL
        val bTest = button("Перевірити", false) {
            Notifier.show(this, "Перевірка", "Так звучатимуть попередження про світло")
        }
        val bSound = button("Звук", false) {
            Notifier.ensure(this)
            try {
                startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH)
                )
            } catch (e: Exception) { }
        }
        (bTest.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bSound.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        soundRow.addView(bTest); soundRow.addView(bSound)
        nCard.addView(soundRow)
        nCard.addView(button("Робота у фоні", false) { setupBackground() })
        col.addView(nCard)

        col.addView(button("Змінити адресу", false) { showAddress() })
        col.addView(tvUpdated)

        tickAction = { updateStatus(); renderSchedule() }
        tickAction?.invoke()
        ui.removeCallbacks(tick); ui.post(tick)
        refreshNow { r -> tvUpdated.text = r }
    }

    private val leads = intArrayOf(5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240)

    private fun notifBlock(parent: LinearLayout, title: String, off: Boolean) {
        val p = Scheduler.prefs(this)
        val kEn = if (off) "notif_off" else "notif_on"
        val kLead = if (off) "lead_off" else "lead_on"
        val enabled = p.getBoolean(kEn, true)

        val sw = Switch(this)
        sw.text = title; sw.textSize = 16f; sw.setTextColor(Color.WHITE); sw.isChecked = enabled
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(0xFFC4B5FD.toInt(), 0xFF9CA3AF.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x887C3AED.toInt(), 0x44FFFFFF))
        sw.setPadding(0, dp(12), 0, dp(4))

        val sp = Spinner(this)
        val labels = leads.map { "За " + Scheduler.leadText(it) }
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        val cur = p.getInt(kLead, 30)
        sp.setSelection(leads.indexOf(cur).let { if (it < 0) 4 else it }, false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (leads[pos] != p.getInt(kLead, 30)) {
                    p.edit().putInt(kLead, leads[pos]).apply()
                    Scheduler.scheduleAll(this@MainActivity)
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) { }
        }
        sp.isEnabled = enabled; sp.alpha = if (enabled) 1f else 0.4f
        sw.setOnCheckedChangeListener { _, on ->
            p.edit().putBoolean(kEn, on).apply()
            sp.isEnabled = on; sp.alpha = if (on) 1f else 0.4f
            Scheduler.scheduleAll(this)
        }

        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        line.gravity = Gravity.CENTER_VERTICAL
        line.addView(label("Попередити", 14f, Pal.GRAY), LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(sp, LinearLayout.LayoutParams(-2, -2))
        parent.addView(sw, LinearLayout.LayoutParams(-1, -2))
        parent.addView(line, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshNow(done: ((String) -> Unit)? = null) {
        Thread {
            val r = Refresher.refresh(this, false)
            runOnUiThread { if (!isFinishing) { done?.invoke(r); tickAction?.invoke() } }
        }.start()
    }

    private fun showCalc() {
        val days = Scheduler.loadDays(this)
        val st = Scheduler.state(this)
        val now = System.currentTimeMillis()
        val sb = StringBuilder()
        if (st == null) {
            sb.append("Даних про графік ще немає.")
        } else {
            val at = st.changeAt
            if (st.off) {
                sb.append("Зараз світла немає.\n")
                if (at != null) sb.append("Увімкнуть о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                val later = st.laterStart
                if (later != null) sb.append("Потім відключення о ${Scheduler.whenText(later)}.\n")
            } else {
                sb.append("Зараз світло є.\n")
                if (at != null) sb.append("Відключення о ${Scheduler.whenText(at)} — через ${Scheduler.dur(at - now)}.\n")
                else sb.append("Найближчих відключень немає.\n")
            }
        }
        val today = LocalDate.now(Scheduler.KYIV)
        fun total(d: LocalDate): String {
            val m = Scheduler.minutesOff(days[d]) ?: return "графік ще не опубліковано"
            return Scheduler.dur(m * 60_000L)
        }
        sb.append("\nБез світла сьогодні: ").append(total(today))
        sb.append("\nБез світла завтра: ").append(total(today.plusDays(1)))
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Розрахунок часу")
            .setMessage(sb.toString())
            .setPositiveButton("Добре", null)
            .show()
    }

    private fun setupBackground() {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                return
            }
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                return
            }
            Toast.makeText(this, "Усе налаштовано ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }

    // ================= Екран адреси (поля в застосунку, сайт VOE прихований) =================
    private fun makeWeb(): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) { v.evaluateJavascript(VA_JS, null) }
        }
        return w
    }

    private fun q(s: String): String = JSONObject.quote(s)

    private fun decode(raw: String?): String? = try {
        val v = JSONTokener(raw ?: "null").nextValue()
        if (v is String) v else null
    } catch (e: Exception) { null }

    /** Виконує JS на прихованій сторінці VOE (спочатку гарантує наявність драйвера). */
    private fun js(code: String, cb: ((String?) -> Unit)? = null) {
        web.evaluateJavascript(VA_JS, null)
        web.evaluateJavascript(code) { cb?.invoke(it) }
    }

    private fun showAddress() {
        onAddress = true; saving = false
        ui.removeCallbacks(tick)
        for (i in 0..2) { chosen[i] = false; typeRun[i]?.let { ui.removeCallbacks(it) } }
        rain.visibility = View.VISIBLE
        holder.removeAllViews()
        val hasAddr = Scheduler.prefs(this).getString("address", null) != null

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(14), dp(18), dp(30))
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        holder.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(label("Ваша адреса", 26f, Pal.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (hasAddr) {
            val close = button("Назад", false) { showMain() }
            (close.layoutParams as LinearLayout.LayoutParams).apply { topMargin = 0; width = -2 }
            close.setPadding(dp(20), dp(8), dp(20), dp(8))
            bar.addView(close)
        }
        col.addView(bar)

        val c = card()
        fieldBlock(c, 0, "Населений пункт", "Почніть вводити назву")
        fieldBlock(c, 1, "Вулиця", "Спочатку оберіть населений пункт")
        fieldBlock(c, 2, "Будинок", "Номер будинку")
        col.addView(c)

        val st = label("", 14f, Pal.GRAY)
        st.setPadding(dp(4), dp(12), dp(4), 0)
        tvStatus = st
        col.addView(st)
        col.addView(button("Перевірити адресу", true) { submitAddress() })

        val diag = label("Не з'являються підказки? Надіслати діагностику", 12f, 0xFFA78BFA.toInt())
        diag.gravity = Gravity.CENTER
        diag.setPadding(0, dp(18), 0, 0)
        diag.setOnClickListener { copyDiag() }
        col.addView(diag)

        web.loadUrl(URL)
    }

    private fun fieldBlock(parent: LinearLayout, idx: Int, title: String, hint: String) {
        val t = label(title, 13f, Pal.GRAY)
        t.setPadding(dp(2), if (idx == 0) 0 else dp(14), 0, dp(6))
        parent.addView(t)

        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(0x66FFFFFF)
        et.setTextColor(Color.WHITE)
        et.textSize = 16f
        et.setSingleLine(true)
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        val bg = GradientDrawable()
        bg.setColor(0xFF1A1330.toInt()); bg.cornerRadius = dpf(14f); bg.setStroke(dp(1), 0x44A78BFA)
        et.background = bg
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun afterTextChanged(s: Editable?) { if (!suppress) onType(idx, s?.toString() ?: "") }
        })
        parent.addView(et, LinearLayout.LayoutParams(-1, -2))

        val sug = LinearLayout(this)
        sug.orientation = LinearLayout.VERTICAL
        sug.visibility = View.GONE
        val sbg = GradientDrawable()
        sbg.setColor(0xFF211A3A.toInt()); sbg.cornerRadius = dpf(14f)
        sug.background = sbg
        parent.addView(sug, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        fieldEt[idx] = et; sugBox[idx] = sug
    }

    private fun setField(idx: Int, text: String) {
        suppress = true
        fieldEt[idx]?.setText(text)
        fieldEt[idx]?.setSelection(text.length)
        suppress = false
    }

    private fun onType(idx: Int, text: String) {
        chosen[idx] = false
        for (j in idx + 1..2) {
            if (fieldEt[j]?.text?.isNotEmpty() == true) setField(j, "")
            chosen[j] = false
            sugBox[j]?.visibility = View.GONE
        }
        sugBox[idx]?.visibility = View.GONE
        typeRun[idx]?.let { ui.removeCallbacks(it) }
        val need = if (idx == 2) 1 else 2
        if (text.trim().length < need) return
        if (idx > 0 && !chosen[idx - 1]) {
            tvStatus?.text = "Спершу оберіть попередній пункт зі списку підказок"
            return
        }
        tvStatus?.text = ""
        val r = Runnable { driveType(idx, text) }
        typeRun[idx] = r
        ui.postDelayed(r, 450)
    }

    private fun driveType(idx: Int, text: String) {
        js("window.__va.type($idx,${q(text)})") { r ->
            if (decode(r) == "noinput") {
                tvStatus?.text = "Сервіс ще завантажується… спробуйте за кілька секунд"
            } else {
                ui.postDelayed({ readSuggestions(idx, text, 0) }, 900)
            }
        }
    }

    private fun readSuggestions(idx: Int, text: String, attempt: Int) {
        if (!onAddress || fieldEt[idx]?.text?.toString() != text) return
        js("window.__va.read($idx,${q(text)})") { r ->
            val arr = try { JSONArray(decode(r) ?: "[]") } catch (e: Exception) { JSONArray() }
            if (arr.length() == 0 && attempt < 3) {
                ui.postDelayed({ readSuggestions(idx, text, attempt + 1) }, 800)
            } else {
                showSuggestions(idx, arr)
            }
        }
    }

    private fun showSuggestions(idx: Int, arr: JSONArray) {
        val box = sugBox[idx] ?: return
        box.removeAllViews()
        if (arr.length() == 0) {
            if (idx < 2) tvStatus?.text = "Нічого не знайдено — перевірте назву"
            box.visibility = View.GONE
            return
        }
        for (i in 0 until arr.length()) {
            val t = arr.getString(i)
            val row = TextView(this)
            row.text = t; row.textSize = 15f; row.setTextColor(Color.WHITE)
            row.setPadding(dp(14), dp(12), dp(14), dp(12))
            val mask = GradientDrawable()
            mask.setColor(Color.WHITE); mask.cornerRadius = dpf(14f)
            row.background = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), null, mask)
            row.isClickable = true
            row.setOnClickListener { pick(idx, i, t) }
            box.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        box.visibility = View.VISIBLE
    }

    private fun pick(idx: Int, i: Int, text: String) {
        js("window.__va.pick($idx,$i)")
        setField(idx, text)
        chosen[idx] = true
        sugBox[idx]?.visibility = View.GONE
        tvStatus?.text = ""
        if (idx < 2) fieldEt[idx + 1]?.requestFocus()
    }

    private fun submitAddress() {
        if (saving) return
        val city = fieldEt[0]?.text?.toString()?.trim() ?: ""
        val street = fieldEt[1]?.text?.toString()?.trim() ?: ""
        val house = fieldEt[2]?.text?.toString()?.trim() ?: ""
        if (!chosen[0] || !chosen[1]) {
            Toast.makeText(this, "Оберіть населений пункт і вулицю зі списку підказок", Toast.LENGTH_LONG).show()
            return
        }
        if (house.isEmpty()) {
            Toast.makeText(this, "Вкажіть номер будинку", Toast.LENGTH_SHORT).show()
            return
        }
        saving = true
        tvStatus?.text = "Шукаю графік…"
        val label = city.substringBefore(" (").trim() + ", " + street + ", " + house
        val go = {
            js("window.__va.submit()") { r ->
                if (decode(r) == "nobtn") fail("Не вдалося відправити запит. Спробуйте ще раз.")
                else { pollTries = 0; ui.postDelayed({ pollResult(label) }, 2500) }
            }
        }
        if (chosen[2]) go() else {
            js("window.__va.type(2,${q(house)})")
            ui.postDelayed({
                js("window.__va.pickExact(2,${q(house)})")
                ui.postDelayed({ go() }, 500)
            }, 1000)
        }
    }

    private fun fail(msg: String) {
        saving = false
        tvStatus?.text = msg
    }

    private fun pollResult(label: String) {
        if (!onAddress) return
        js(SCRAPE_JS) { r ->
            var sc: Scraped? = null
            try {
                val s = decode(r)
                if (s != null) sc = parseScraped(JSONObject(s))
            } catch (e: Exception) { }
            if (sc != null) {
                sc.addr = label
                saveAddress(sc)
            } else if (++pollTries < 20) {
                ui.postDelayed({ pollResult(label) }, 1500)
            } else {
                fail("Не вдалося отримати графік. Перевірте адресу й спробуйте ще раз.")
            }
        }
    }

    private fun copyDiag() {
        js("window.__va.diag()") { r ->
            val s = decode(r) ?: "порожньо"
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("diag", s))
            Toast.makeText(this, "Діагностику скопійовано — вставте її в чат", Toast.LENGTH_LONG).show()
        }
    }

    private fun parseScraped(o: JSONObject): Scraped? {
        val heads = o.getJSONArray("heads")
        val rows = o.getJSONArray("rows")
        if (rows.length() == 0) return null
        val today = LocalDate.now(Scheduler.KYIV)
        val ncols = rows.getJSONObject(0).getJSONArray("v").length()
        if (ncols == 0) return null
        val dates = ArrayList<LocalDate>()
        for (i in 0 until ncols) {
            var d = today.plusDays(i.toLong())
            if (i < heads.length()) {
                val m = Regex("(\\d{1,2})\\.(\\d{1,2})").find(heads.getString(i))
                if (m != null) {
                    val day = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt()
                    var y = today.year
                    if (mo == 1 && today.monthValue == 12) y++
                    if (mo == 12 && today.monthValue == 1) y--
                    try { d = LocalDate.of(y, mo, day) } catch (e: Exception) { }
                }
            }
            dates.add(d)
        }
        val masks = HashMap<LocalDate, BooleanArray>()
        for (d in dates) masks[d] = BooleanArray(24)
        for (r in 0 until rows.length()) {
            val row = rows.getJSONObject(r)
            val hour = row.getInt("h")
            val v = row.getJSONArray("v")
            if (hour !in 0..23) continue
            for (i in 0 until minOf(ncols, v.length())) masks[dates[i]]!![hour] = v.getInt(i) == 2
        }
        val days = Days()
        for ((d, mask) in masks) {
            val list = ArrayList<IntArray>()
            var start = -1
            for (h in 0..24) {
                val on = h < 24 && mask[h]
                if (on && start < 0) start = h
                if (!on && start >= 0) { list.add(intArrayOf(start * 60, h * 60)); start = -1 }
            }
            days[d] = list
        }
        val q = if (o.isNull("queue")) null else o.getString("queue")
        return Scraped(masks, days, q, o.optString("addr", ""))
    }

    private fun saveAddress(sc: Scraped) {
        if (saving) return
        saving = true
        tvStatus?.text = "Зберігаю…"
        Thread {
            try {
                var group = sc.queue?.takeIf { it in Refresher.GROUPS }
                if (group != null) {
                    val s = Refresher.score(group, sc.masks)
                    if (s != null && s.second > 0 && s.first < s.second * 0.85) group = null
                }
                if (group == null) group = Refresher.detectGroup(sc.masks)
                val ed = Scheduler.prefs(this).edit()
                ed.putString("address", sc.addr.ifBlank { "Моя адреса" })
                if (group != null) ed.putString("group", group) else ed.remove("group")
                ed.apply()
                Scheduler.update(this, sc.days)
                if (group != null) Refresher.refresh(this, false)
                Refresher.schedulePeriodic(this)
                runOnUiThread {
                    showMain()
                    val p = Scheduler.prefs(this)
                    if (!p.getBoolean("bg_asked", false)) {
                        p.edit().putBoolean("bg_asked", true).apply()
                        setupBackground()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { saving = false; Toast.makeText(this, "Не вдалося зберегти: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    companion object {
        const val URL = "https://disconnection.voe.com.ua/"

        /** Драйвер прихованої сторінки VOE: вводить текст у поля, читає підказки, тисне кнопку. */
        const val VA_JS = """(function(){if(window.__va)return;
var NAMES=['населений пункт','вулиця','будинок'];
function vis(e){var r=e.getBoundingClientRect();return r.width>0&&r.height>0;}
function ins(){return Array.prototype.filter.call(document.querySelectorAll('input'),function(i){var t=(i.type||'text').toLowerCase();return t!=='hidden'&&t!=='radio'&&t!=='checkbox'&&t!=='button'&&t!=='submit'&&vis(i);});}
function field(idx){
 var a=ins(),L=document.querySelectorAll('label,div,span,p,h2,h3,h4,b,strong');
 for(var i=0;i<L.length;i++){var l=L[i];if(l.tagName!=='LABEL'&&l.children.length>0)continue;
  var t=(l.innerText||'').trim().toLowerCase();
  if(t===NAMES[idx]){for(var j=0;j<a.length;j++){if(l.compareDocumentPosition(a[j])&4)return a[j];}}}
 return a[idx]||null;}
function setv(el,v){var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(el,v);
 ['input','change'].forEach(function(n){el.dispatchEvent(new Event(n,{bubbles:true}));});
 ['keydown','keyup'].forEach(function(n){el.dispatchEvent(new KeyboardEvent(n,{bubbles:true,key:'a'}));});}
function click(e){['mousedown','mouseup','click'].forEach(function(n){e.dispatchEvent(new MouseEvent(n,{bubbles:true,cancelable:true,view:window}));});}
function read(idx,v){
 var el=field(idx);if(!el)return [];
 Array.prototype.forEach.call(document.querySelectorAll('[data-va]'),function(x){x.removeAttribute('data-va');});
 var ir=el.getBoundingClientRect(),ql=v.toLowerCase(),seen={},out=[],all=document.querySelectorAll('body *');
 for(var i=0;i<all.length;i++){var e=all[i];
  if(e===el||e.contains(el)||el.contains(e))continue;
  var tg=e.tagName;if(tg==='SCRIPT'||tg==='STYLE'||tg==='INPUT')continue;
  var r=e.getBoundingClientRect();
  if(r.width<=0||r.height<18||r.height>90)continue;
  if(r.top<ir.bottom-4||r.top>ir.bottom+700)continue;
  if(r.left<ir.left-30||r.left>ir.right)continue;
  var t=(e.innerText||'').trim();if(t.length<1||t.length>200)continue;
  var tl=t.toLowerCase();if(tl.indexOf(ql)<0)continue;
  var dup=false;for(var k=0;k<e.children.length;k++){if(((e.children[k].innerText||'').trim())===t){dup=true;break;}}
  if(dup||seen[tl])continue;seen[tl]=1;
  e.setAttribute('data-va',String(out.length));out.push(t.replace(/\s+/g,' '));
  if(out.length>=8)break;}
 return out;}
window.__va={
 type:function(idx,v){var el=field(idx);if(!el)return 'noinput';el.focus();el.click();setv(el,v);return 'ok';},
 read:function(idx,v){return JSON.stringify(read(idx,v));},
 pick:function(idx,i){var e=document.querySelector('[data-va="'+i+'"]');if(!e)return 'none';click(e);return 'ok';},
 pickExact:function(idx,v){var o=read(idx,v);for(var i=0;i<o.length;i++){if(o[i].toLowerCase()===v.toLowerCase()){var e=document.querySelector('[data-va="'+i+'"]');if(e){click(e);return 'ok';}}}return 'none';},
 submit:function(){var els=document.querySelectorAll('button,a,input[type=submit],[role=button]');
  for(var i=0;i<els.length;i++){var t=(els[i].innerText||els[i].value||'');if(/перевірити\s+адресу/i.test(t)){click(els[i]);return 'ok';}}return 'nobtn';},
 diag:function(){var o={url:location.href,inputs:[],buttons:[]};
  Array.prototype.forEach.call(document.querySelectorAll('input'),function(i){o.inputs.push({type:i.type,name:i.name,id:i.id,ph:i.placeholder,dis:i.disabled,val:i.value,html:i.outerHTML.slice(0,300),parent:i.parentElement?i.parentElement.outerHTML.slice(0,600):''});});
  Array.prototype.forEach.call(document.querySelectorAll('button,[role=button]'),function(b){o.buttons.push(((b.innerText||'').trim().slice(0,60))+' | '+b.className);});
  var f=document.querySelector('form')||document.body;o.form=f.outerHTML.slice(0,6000);return JSON.stringify(o);}
};})()"""

        const val SCRAPE_JS = """(function(){try{
var tabs=document.querySelectorAll('table'),tb=null;
for(var i=0;i<tabs.length;i++){if(/Часові\s+проміжки/i.test(tabs[i].innerText)){tb=tabs[i];break;}}
if(!tb)return null;
function cls(el){
 var nodes=[el].concat(Array.prototype.slice.call(el.querySelectorAll('*')));
 for(var k=0;k<nodes.length;k++){
  var m=getComputedStyle(nodes[k]).backgroundColor.match(/[\d.]+/g);
  if(!m)continue;
  var r=+m[0],g=+m[1],b=+m[2],a=m.length>3?+m[3]:1;
  if(a<0.5)continue;
  if(r>200&&g>50&&g<165&&b<110)return 2;
  if(r>220&&g>=165&&b<110)return 1;
 }
 return 0;
}
var rows=tb.querySelectorAll('tr'),heads=[],data=[];
for(var i=0;i<rows.length;i++){
 var cells=rows[i].children;if(!cells.length)continue;
 var first=(cells[0].innerText||'').trim();
 var hm=first.match(/^(\d{1,2})\s*[-–]\s*(\d{1,2})$/);
 if(hm){var arr=[];for(var j=1;j<cells.length;j++)arr.push(cls(cells[j]));data.push({h:+hm[1],v:arr});}
 else if(/Часові/i.test(first)){for(var j=1;j<cells.length;j++)heads.push((cells[j].innerText||'').trim());}
}
if(!data.length)return null;
var inputs=document.querySelectorAll('input'),addr=[];
for(var i=0;i<inputs.length;i++){var v=(inputs[i].value||'').trim();var t=inputs[i].type;
 if(v&&t!=='hidden'&&t!=='radio'&&t!=='checkbox')addr.push(v);}
var q=(document.body.innerText||'').match(/(?:[Чч]ерг[аиу]|[Гг]руп[аиу])[^0-9\n]{0,20}(\d)\.(\d)/);
return JSON.stringify({heads:heads,rows:data,addr:addr.join(', '),queue:q?q[1]+'.'+q[2]:null});
}catch(e){return null;}})()"""
    }
}
